# Temperature Monitoring - Code Integration Guide
## Quick Implementation for Hackathon MVP

---

## 🚀 What You Need to Add (Total Time: 1-2 Hours)

### Step 1: Firmware Enhancement (30 minutes)

**File:** `ESP32_FIRMWARE.ino`

**Add temperature baseline detection:**

Find this section in `ESP32_FIRMWARE.ino`:
```cpp
// Baseline data (hour-by-hour)
float baseline[24] = { 0.0, 0.0, ... };
```

Add this **AFTER** the flow baseline:
```cpp
// Temperature baseline (hour-by-hour, in Celsius)
// Average expected water temperature by hour of day
float tempBaseline[24] = {
  12.0,  // 0:00 - 1:00 (midnight - coldest)
  11.8,  // 1:00 - 2:00
  11.5,  // 2:00 - 3:00
  11.2,  // 3:00 - 4:00
  12.0,  // 4:00 - 5:00
  15.0,  // 5:00 - 6:00 (early usage)
  22.5,  // 6:00 - 7:00 (morning showers - HOT)
  24.0,  // 7:00 - 8:00 (peak - breakfast)
  18.0,  // 8:00 - 9:00 (cooling)
  14.5,  // 9:00 - 10:00
  13.5,  // 10:00 - 11:00
  13.2,  // 11:00 - 12:00 (minimal)
  14.0,  // 12:00 - 13:00 (lunch)
  13.8,  // 13:00 - 14:00
  13.5,  // 14:00 - 15:00
  13.8,  // 15:00 - 16:00
  18.5,  // 16:00 - 17:00 (pre-dinner)
  26.0,  // 17:00 - 18:00 (dinner - HOT)
  25.5,  // 18:00 - 19:00
  22.0,  // 19:00 - 20:00 (evening showers)
  18.5,  // 20:00 - 21:00
  16.0,  // 21:00 - 22:00
  14.0,  // 22:00 - 23:00
  12.5   // 23:00 - 0:00
};
```

**Add temperature anomaly detection function:**

Add this new function after `detectLeaks()`:
```cpp
void detectTemperatureAnomalies() {
  // Get current hour
  time_t now = time(nullptr);
  struct tm* timeinfo = localtime(&now);
  int currentHour = timeinfo->tm_hour;
  
  float expectedTemp = tempBaseline[currentHour];
  float tempDifference = temperatureC - expectedTemp;
  
  // FREEZE RISK (most critical)
  if (temperatureC < 2) {
    if (!alertActive) {
      triggerFreezeRiskAlert();
    }
    return;  // Don't check other alerts
  }
  
  // COLD WATER ANOMALY (sudden drop)
  if (tempDifference < -5 && temperatureC > 5) {
    Serial.println("Temperature anomaly detected!");
    Serial.print("Expected: ");
    Serial.print(expectedTemp, 1);
    Serial.print("°C, Actual: ");
    Serial.print(temperatureC, 1);
    Serial.println("°C");
    
    if (!alertActive) {
      triggerColdWaterAnomalyAlert(expectedTemp);
    }
  }
  
  // HOT WATER OVERHEAT (possible heater malfunction)
  if (temperatureC > 60) {
    Serial.println("Hot water overheat detected!");
    
    if (!alertActive) {
      triggerHotWaterOverheatAlert();
    }
  }
}

void triggerFreezeRiskAlert() {
  Serial.println("!!! CRITICAL: FREEZE RISK !!!");
  Serial.print("Pipe temperature: ");
  Serial.print(temperatureC);
  Serial.println("°C");
  
  // Continuous alarm
  for (int i = 0; i < 10; i++) {
    digitalWrite(LED_RED, HIGH);
    tone(BUZZER_PIN, 2000, 100);  // 2kHz beep
    delay(200);
    digitalWrite(LED_RED, LOW);
    delay(200);
  }
  
  // Log to Firebase
  FirebaseJson json;
  json.set("timestamp", (long)time(nullptr));
  json.set("type", "FREEZE_RISK");
  json.set("severity", "CRITICAL");
  json.set("temp_c", temperatureC);
  json.set("message", "Freeze risk detected - Protect outdoor pipes!");
  
  Firebase.pushJSON(firebaseData, "/alerts", json);
  
  alertActive = true;
}

void triggerColdWaterAnomalyAlert(float expectedTemp) {
  Serial.println("Cold water temperature anomaly!");
  
  blinkLED(LED_RED, 3);
  tone(BUZZER_PIN, 1200, 300);
  
  FirebaseJson json;
  json.set("timestamp", (long)time(nullptr));
  json.set("type", "COLD_WATER_ANOMALY");
  json.set("severity", "MEDIUM");
  json.set("temp_c", temperatureC);
  json.set("expected_temp_c", expectedTemp);
  json.set("difference_c", temperatureC - expectedTemp);
  
  Firebase.pushJSON(firebaseData, "/alerts", json);
  
  alertActive = true;
}

void triggerHotWaterOverheatAlert() {
  Serial.println("Hot water overheat detected!");
  
  blinkLED(LED_RED, 5);
  tone(BUZZER_PIN, 1500, 200);
  delay(200);
  tone(BUZZER_PIN, 1500, 200);
  
  FirebaseJson json;
  json.set("timestamp", (long)time(nullptr));
  json.set("type", "HOT_WATER_OVERHEAT");
  json.set("severity", "MEDIUM");
  json.set("temp_c", temperatureC);
  json.set("message", "Water heater temperature very high - check system");
  
  Firebase.pushJSON(firebaseData, "/alerts", json);
  
  alertActive = true;
}
```

**Add to main loop:**

Find the `detectLeaks()` call in `loop()`:
```cpp
// Detect leaks
detectLeaks();
```

Add temperature detection right after:
```cpp
// Detect temperature anomalies
detectTemperatureAnomalies();
```

---

### Step 2: Update HomeScreen (30 minutes)

**File:** `src/screens/HomeScreen.js`

**Add temperature card after the pressure card:**

Find this section:
```javascript
{/* Pressure */}
<View style={styles.metricCard}>
  <View style={styles.metricHeader}>
    <Ionicons name="pulse" size={24} color="#FF9800" />
    <Text style={styles.metricLabel}>Pressure</Text>
  </View>
  ...
</View>
```

Add this **AFTER** the pressure card:
```javascript
{/* Temperature */}
<View style={styles.metricCard}>
  <View style={styles.metricHeader}>
    <Ionicons name="thermometer" size={24} color="#E91E63" />
    <Text style={styles.metricLabel}>Water Temperature</Text>
  </View>
  <Text style={styles.metricValue}>
    {currentReadings.temp_c.toFixed(1)}°C ({(currentReadings.temp_c * 9/5 + 32).toFixed(1)}°F)
  </Text>
  <Text style={styles.metricDescription}>
    {currentReadings.temp_c < 2 ? '🧊 FREEZE RISK!' :
     currentReadings.temp_c < 10 ? '❄️ Very cold' :
     currentReadings.temp_c < 20 ? '💧 Cold water' :
     currentReadings.temp_c < 40 ? '🌡️ Moderate' :
     currentReadings.temp_c < 50 ? '🔥 Hot water' :
     '⚠️ Very hot - check heater'}
  </Text>
</View>
```

---

### Step 3: Update SensorsScreen (30 minutes)

**File:** `src/screens/SensorsScreen.js`

**Add temperature history tracking:**

In the `useEffect` hook where you're collecting flow and pressure history, add:

```javascript
// Initialize temperature history state
const [tempHistory, setTempHistory] = useState([]);

// In the subscribeToCurrentReadings callback, add:
setTempHistory((prev) => {
  const newHistory = [
    ...prev,
    {
      value: parseFloat(data.temp_c.toFixed(1)),
      label: new Date(data.timestamp * 1000).toLocaleTimeString().substring(0, 5),
    },
  ];
  return newHistory.slice(-60);  // Keep last 60 readings (1 hour)
});
```

**Add temperature chart after pressure chart:**

Find the Pressure Chart section and add this after it:
```javascript
{/* Temperature Chart */}
<View style={styles.chartCard}>
  <View style={styles.chartHeader}>
    <Text style={styles.chartTitle}>Temperature (°C)</Text>
    <Text style={styles.chartValue}>
      {currentReadings.temp_c.toFixed(1)}°C
    </Text>
  </View>
  <View style={styles.chartContainer}>
    {tempHistory.length > 1 ? (
      <LineChart
        areaChart
        curved
        data={tempHistory}
        height={220}
        width={SCREEN_WIDTH - 52}
        showVerticalLines
        verticalLinesColor="#e0e0e0"
        color="#E91E63"
        startFillColor="#E91E63"
        startOpacity={0.1}
        endOpacity={0}
        xAxisColor="#e0e0e0"
        yAxisColor="#e0e0e0"
        yAxisLabelWidth={40}
        hideRules={false}
        rulesColor="#e0e0e0"
        yAxisTextStyle={{fontSize: 10, color: '#666'}}
        xAxisLabelTextStyle={{fontSize: 10, color: '#666', marginTop: 8}}
      />
    ) : (
      <Text style={styles.noDataText}>Collecting temperature data...</Text>
    )}
  </View>
  <View style={styles.chartInfo}>
    <View style={styles.infoItem}>
      <Text style={styles.infoLabel}>Status</Text>
      <Text style={[
        styles.infoValue,
        { color: currentReadings.temp_c < 5 ? '#F44336' : '#4CAF50' }
      ]}>
        {currentReadings.temp_c < 2 ? 'FREEZE RISK' :
         currentReadings.temp_c < 10 ? 'Cold' :
         currentReadings.temp_c < 40 ? 'Normal' :
         'Hot'}
      </Text>
    </View>
    <View style={styles.infoItem}>
      <Text style={styles.infoLabel}>Readings</Text>
      <Text style={styles.infoValue}>{tempHistory.length}</Text>
    </View>
  </View>
</View>
```

---

### Step 4: Update HistoryScreen (15 minutes)

**File:** `src/screens/HistoryScreen.js`

The temperature alerts will **automatically** appear in History because they're logged to Firebase `/alerts` node.

**Optional:** Add filtering for temperature alerts:

```javascript
const getAlertDescription = (alert) => {
  switch (alert.type) {
    case 'FLOW_SPIKE':
      return `Flow spike detected: ${alert.flow_gpm.toFixed(2)} GPM`;
    case 'PRESSURE_DROP':
      return `Pressure drop detected: ${alert.pressure_psi.toFixed(1)} PSI`;
    case 'MOISTURE_DETECTED':
      return `Water detected at: ${alert.location}`;
    case 'FREEZE_RISK':  // Add this
      return `Freeze risk! Temperature: ${alert.temp_c.toFixed(1)}°C`;
    case 'COLD_WATER_ANOMALY':  // Add this
      return `Cold water anomaly: ${alert.temp_c.toFixed(1)}°C (expected ${alert.expected_temp_c.toFixed(1)}°C)`;
    case 'HOT_WATER_OVERHEAT':  // Add this
      return `Hot water overheat: ${alert.temp_c.toFixed(1)}°C - Check heater`;
    default:
      return 'Alert triggered';
  }
};
```

---

### Step 5: Update SettingsScreen (15 minutes)

**File:** `src/screens/SettingsScreen.js`

Add temperature threshold settings:

```javascript
// In your settings sections array, add:
{
  title: 'Temperature Monitoring',
  data: [
    {
      id: 'freeze_threshold',
      label: 'Freeze Alert Temperature',
      description: 'Alert when water temperature drops below this',
      value: localSettings.freeze_threshold || 2,
      min: -5,
      max: 10,
      step: 1,
      type: 'number',
      unit: '°C',
    },
    {
      id: 'overheat_threshold',
      label: 'Overheat Alert Temperature',
      description: 'Alert when water temperature exceeds this',
      value: localSettings.overheat_threshold || 60,
      min: 45,
      max: 85,
      step: 5,
      type: 'number',
      unit: '°C',
    },
  ],
}
```

---

## 📝 Test Checklist

After implementing, verify:

- [ ] HomeScreen shows temperature value
- [ ] Temperature gauge color changes based on value
- [ ] SensorsScreen shows temperature chart
- [ ] Temperature chart updates in real-time (2-5 sec)
- [ ] Test freeze alert: Set Firebase temp to 0°C → should trigger alert
- [ ] Test cold water anomaly: Set temp to 5°C when expecting 20°C
- [ ] Test hot water overheat: Set temp to 65°C
- [ ] Alerts appear in History screen
- [ ] Settings allow threshold adjustment
- [ ] Buzzer/LED responds to temperature alerts

---

## 🎯 Quick Reference - What Changed

| File | Changes | Lines |
|------|---------|-------|
| `ESP32_FIRMWARE.ino` | Added tempBaseline[24], detectTemperatureAnomalies(), 3 alert functions | ~150 |
| `HomeScreen.js` | Added temperature metric card | ~15 |
| `SensorsScreen.js` | Added tempHistory state, temperature chart | ~50 |
| `HistoryScreen.js` | Added temperature alert descriptions (optional) | ~3 |
| `SettingsScreen.js` | Added temperature threshold settings (optional) | ~20 |

**Total additions:** ~240 lines of code  
**Total time:** 1.5-2 hours

---

## 💡 Advanced (Optional - If Time Permits)

**Add machine learning baseline:**

```cpp
// After 7 days of operation, automatically update baseline
if (daysRunning > 7) {
  // Average last 7 days of data
  tempBaseline[currentHour] = calculateAverage(lastWeekTemp[currentHour]);
  
  // Upload updated baseline to Firebase
  Firebase.setFloat(firebaseData, "/baseline_temperature/" + currentHour, tempBaseline[currentHour]);
}
```

**Add seasonal adjustment:**

```cpp
// Winter adjustment (lower expected temps)
float seasonalAdjustment = 0;
if (currentMonth >= 11 || currentMonth <= 2) {
  seasonalAdjustment = -3;  // 3°C colder in winter
} else if (currentMonth >= 6 && currentMonth <= 8) {
  seasonalAdjustment = +2;  // 2°C warmer in summer
}

float adjustedBaseline = tempBaseline[currentHour] + seasonalAdjustment;
```

---

## 🎉 You're Done!

Temperature monitoring is now fully integrated. The system will:

✅ Display real-time temperature  
✅ Show temperature trends  
✅ Alert on freeze risk  
✅ Alert on cold/hot anomalies  
✅ Log all temperature events  
✅ Allow threshold configuration  

**Next steps:**
- Test with real data
- Verify all alerts work
- Adjust thresholds based on your location
- Consider adding smart thermostat integration (Phase 2)

---

**Total implementation time: 1.5-2 hours**  
**Complexity: Low-Medium**  
**Impact: High (freeze prevention alone worth $10K+ property damage)**

