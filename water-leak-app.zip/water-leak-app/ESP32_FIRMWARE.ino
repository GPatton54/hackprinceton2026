#include <WiFi.h>
#include <FirebaseESP32.h>
#include <DHT.h>
#include <Wire.h>

// ============================================================================
// CONFIGURATION - UPDATE THESE VALUES
// ============================================================================

// WiFi Configuration
#define WIFI_SSID "YOUR_WIFI_SSID"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"

// Firebase Configuration
#define FIREBASE_HOST "YOUR_PROJECT.firebaseio.com"
#define FIREBASE_AUTH "YOUR_DATABASE_SECRET"

// Pin Definitions
#define FLOW_SENSOR_PIN 2        // GPIO 2 - YF-S201 flow sensor
#define PRESSURE_SENSOR_SDA 21   // GPIO 21 - I2C SDA (HFS301)
#define PRESSURE_SENSOR_SCL 22   // GPIO 22 - I2C SCL (HFS301)
#define DHT_PIN 4                // GPIO 4 - DHT22 temperature/humidity
#define MOISTURE_KITCHEN 34      // GPIO 34 (ADC) - Kitchen moisture
#define MOISTURE_BASEMENT 35     // GPIO 35 (ADC) - Basement moisture
#define MOISTURE_BATHROOM 36     // GPIO 36 (ADC) - Bathroom moisture
#define SOLENOID_VALVE_PIN 17    // GPIO 17 - Solenoid valve control
#define BUZZER_PIN 5             // GPIO 5 - Alert buzzer
#define LED_RED 25               // GPIO 25 - Red LED
#define LED_GREEN 26             // GPIO 26 - Green LED

// Sensor Configuration
#define DHT_TYPE DHT22
#define FLOW_SENSOR_CALIBRATION 2.67  // mL per pulse for YF-S201
#define PRESSURE_I2C_ADDRESS 0x76      // HFS301 I2C address
#define SAMPLING_INTERVAL 1000         // 1 second sampling
#define FIREBASE_SYNC_INTERVAL 5000    // Sync to Firebase every 5 seconds

// Detection Thresholds
#define FLOW_SPIKE_DURATION 30         // Seconds of sustained anomaly
#define PRESSURE_DROP_THRESHOLD 15     // % drop to trigger alert
#define MOISTURE_THRESHOLD 400         // ADC units (dry < 300, wet > 400)

// ============================================================================
// GLOBAL VARIABLES
// ============================================================================

FirebaseData firebaseData;
DHT dht(DHT_PIN, DHT_TYPE);

// Sensor readings
volatile long flowPulseCount = 0;
float flowGPM = 0;
float pressurePSI = 0;
float temperatureC = 0;
int moistureKitchen = 0;
int moistureBasement = 0;
int moistureBathroom = 0;
float baselineAnomalyPercent = 0;

// Baseline data (hour-by-hour)
float baseline[24] = {
  0.0,   // 0:00 - 1:00 (2am)
  0.0,   // 1:00 - 2:00 (3am)
  0.05,  // 2:00 - 3:00 (4am)
  0.1,   // 3:00 - 4:00 (5am)
  0.2,   // 4:00 - 5:00 (6am)
  0.5,   // 5:00 - 6:00 (7am - morning routine starts)
  1.5,   // 6:00 - 7:00 (8am - peak)
  1.8,   // 7:00 - 8:00 (9am)
  1.2,   // 8:00 - 9:00 (10am)
  0.8,   // 9:00 - 10:00 (11am)
  0.6,   // 10:00 - 11:00 (12pm)
  0.7,   // 11:00 - 12:00 (1pm)
  0.9,   // 12:00 - 13:00 (2pm)
  1.1,   // 13:00 - 14:00 (3pm)
  0.8,   // 14:00 - 15:00 (4pm)
  1.2,   // 15:00 - 16:00 (5pm)
  1.5,   // 16:00 - 17:00 (6pm - evening)
  2.0,   // 17:00 - 18:00 (7pm - dinner)
  1.8,   // 18:00 - 19:00 (8pm)
  1.5,   // 19:00 - 20:00 (9pm)
  1.2,   // 20:00 - 21:00 (10pm)
  0.9,   // 21:00 - 22:00 (11pm)
  0.5,   // 22:00 - 23:00 (12am)
  0.1    // 23:00 - 0:00 (1am)
};

// Tracking
unsigned long lastSampleTime = 0;
unsigned long lastFirebaseSyncTime = 0;
unsigned long flowAnomalyStartTime = 0;
bool valveOpen = true;
bool alertActive = false;

// ============================================================================
// SETUP
// ============================================================================

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("\n\n========================================");
  Serial.println("Water Leak Detection System - Starting");
  Serial.println("========================================\n");
  
  // Initialize pins
  pinMode(FLOW_SENSOR_PIN, INPUT);
  pinMode(MOISTURE_KITCHEN, INPUT);
  pinMode(MOISTURE_BASEMENT, INPUT);
  pinMode(MOISTURE_BATHROOM, INPUT);
  pinMode(SOLENOID_VALVE_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  
  // Set initial states
  digitalWrite(SOLENOID_VALVE_PIN, HIGH);  // Valve open (active HIGH)
  digitalWrite(BUZZER_PIN, LOW);           // Buzzer off
  digitalWrite(LED_RED, LOW);
  digitalWrite(LED_GREEN, HIGH);           // Green: normal operation
  
  // Initialize I2C for pressure sensor
  Wire.begin(PRESSURE_SENSOR_SDA, PRESSURE_SENSOR_SCL);
  
  // Initialize DHT22
  dht.begin();
  
  // Setup flow sensor interrupt
  attachInterrupt(digitalPinToInterrupt(FLOW_SENSOR_PIN), 
                  flowSensorISR, RISING);
  
  // Connect to WiFi
  connectToWiFi();
  
  // Initialize Firebase
  Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
  Firebase.reconnectWiFi(true);
  
  Serial.println("Setup complete!\n");
}

// ============================================================================
// MAIN LOOP
// ============================================================================

void loop() {
  unsigned long currentTime = millis();
  
  // Read sensors every SAMPLING_INTERVAL ms
  if (currentTime - lastSampleTime >= SAMPLING_INTERVAL) {
    lastSampleTime = currentTime;
    
    // Read all sensors
    readFlowSensor();
    readPressureSensor();
    readTemperatureSensor();
    readMoistureSensors();
    
    // Detect leaks
    detectLeaks();
    
    // Print debug info to Serial
    printDebugInfo();
  }
  
  // Sync to Firebase every FIREBASE_SYNC_INTERVAL ms
  if (currentTime - lastFirebaseSyncTime >= FIREBASE_SYNC_INTERVAL) {
    lastFirebaseSyncTime = currentTime;
    syncToFirebase();
  }
  
  // Check for commands from app
  checkForCommands();
  
  delay(10);  // Small delay to prevent watchdog timeout
}

// ============================================================================
// SENSOR READING FUNCTIONS
// ============================================================================

void flowSensorISR() {
  flowPulseCount++;
}

void readFlowSensor() {
  // Convert pulses to GPM
  // YF-S201: 1 pulse = 2.67 mL, so 1 L/min = 374.8 pulses/min
  // 1 pulse/second = 2.67 mL/s = 0.16 L/min = 0.0423 GPM
  
  float pulseFrequency = flowPulseCount;  // Pulses in last second
  flowGPM = (pulseFrequency / 374.8) * 60;  // Convert to GPM
  
  // Apply EMA filter to smooth noise
  static float filteredFlow = 0;
  float alpha = 0.2;  // Smoothing factor
  filteredFlow = (alpha * flowGPM) + ((1 - alpha) * filteredFlow);
  flowGPM = filteredFlow;
  
  // Reset counter for next second
  flowPulseCount = 0;
}

void readPressureSensor() {
  // HFS301 I2C pressure sensor
  // Read pressure value from I2C
  // This is a simplified example - actual I2C read would be needed
  
  Wire.beginTransmission(PRESSURE_I2C_ADDRESS);
  Wire.write(0xF1);  // Read pressure register
  Wire.endTransmission(false);
  Wire.requestFrom(PRESSURE_I2C_ADDRESS, 3);
  
  if (Wire.available()) {
    byte statusByte = Wire.read();
    byte pressureHigh = Wire.read();
    byte pressureLow = Wire.read();
    
    // Combine bytes to get 16-bit value
    uint16_t pressureRaw = (pressureHigh << 8) | pressureLow;
    
    // Convert to PSI (0-100 bar = 0-1450 PSI)
    pressurePSI = (pressureRaw / 65535.0) * 1450.0;
    
    // Apply EMA filter
    static float filteredPressure = 50;
    float alpha = 0.2;
    filteredPressure = (alpha * pressurePSI) + ((1 - alpha) * filteredPressure);
    pressurePSI = filteredPressure;
  }
}

void readTemperatureSensor() {
  float temperature = dht.readTemperature();
  
  if (!isnan(temperature)) {
    temperatureC = temperature;
  } else {
    Serial.println("Error reading temperature!");
  }
}

void readMoistureSensors() {
  // Read analog moisture sensors
  // Raw ADC: 0-4095 (0V-3.3V)
  // Dry: ~200-300 ADC units
  // Wet: ~400-1000 ADC units
  
  moistureKitchen = analogRead(MOISTURE_KITCHEN);
  moistureBasement = analogRead(MOISTURE_BASEMENT);
  moistureBathroom = analogRead(MOISTURE_BATHROOM);
  
  // Apply simple moving average filter (last 5 readings)
  static int kitchenBuffer[5] = {0};
  static int basementBuffer[5] = {0};
  static int bathroomBuffer[5] = {0};
  
  // Shift and add new value
  for (int i = 4; i > 0; i--) {
    kitchenBuffer[i] = kitchenBuffer[i-1];
    basementBuffer[i] = basementBuffer[i-1];
    bathroomBuffer[i] = bathroomBuffer[i-1];
  }
  kitchenBuffer[0] = moistureKitchen;
  basementBuffer[0] = moistureBasement;
  bathroomBuffer[0] = moistureBathroom;
  
  // Average
  int kitchenAvg = 0, basementAvg = 0, bathroomAvg = 0;
  for (int i = 0; i < 5; i++) {
    kitchenAvg += kitchenBuffer[i];
    basementAvg += basementBuffer[i];
    bathroomAvg += bathroomBuffer[i];
  }
  moistureKitchen = kitchenAvg / 5;
  moistureBasement = basementAvg / 5;
  moistureBathroom = bathroomAvg / 5;
}

// ============================================================================
// LEAK DETECTION
// ============================================================================

void detectLeaks() {
  // Get current hour for baseline lookup
  time_t now = time(nullptr);
  struct tm* timeinfo = localtime(&now);
  int currentHour = timeinfo->tm_hour;
  
  float baselineForHour = baseline[currentHour];
  
  // FACTOR 1: Flow anomaly detection
  float anomalyPercent = 0;
  if (baselineForHour > 0) {
    anomalyPercent = ((flowGPM - baselineForHour) / baselineForHour) * 100;
  }
  baselineAnomalyPercent = max(0.0f, anomalyPercent);  // Don't show negative anomaly
  
  // Check if flow is significantly above baseline (>50%)
  if (flowGPM > baselineForHour * 1.5 && flowGPM > 0.5) {
    // Sustained anomaly for FLOW_SPIKE_DURATION seconds
    if (flowAnomalyStartTime == 0) {
      flowAnomalyStartTime = millis();
    } else if ((millis() - flowAnomalyStartTime) > FLOW_SPIKE_DURATION * 1000) {
      triggerFlowSpikeLeak(currentHour);
    }
  } else {
    flowAnomalyStartTime = 0;  // Reset timer
  }
  
  // FACTOR 2: Pressure drop (possible burst pipe)
  float expectedPressure = 50.0;  // PSI (typical household)
  if (pressurePSI < (expectedPressure * (100 - PRESSURE_DROP_THRESHOLD) / 100)) {
    if (flowGPM == 0) {
      triggerPressureDropLeak();
    }
  }
  
  // FACTOR 3: Moisture detection (CRITICAL - emergency shutoff)
  if (moistureKitchen > MOISTURE_THRESHOLD || 
      moistureBasement > MOISTURE_THRESHOLD || 
      moistureBathroom > MOISTURE_THRESHOLD) {
    triggerMoistureLeak();
  }
}

void triggerFlowSpikeLeak(int hour) {
  Serial.println("LEAK DETECTED: FLOW SPIKE");
  Serial.print("  Flow: ");
  Serial.print(flowGPM);
  Serial.print(" GPM | Baseline: ");
  Serial.print(baseline[hour]);
  Serial.println(" GPM");
  
  alertActive = true;
  blinkLED(LED_RED, 3);
  tone(BUZZER_PIN, 1000, 500);  // 1kHz beep for 500ms
  
  // Log to Firebase
  FirebaseJson json;
  json.set("timestamp", (long)time(nullptr));
  json.set("type", "FLOW_SPIKE");
  json.set("severity", "HIGH");
  json.set("flow_gpm", flowGPM);
  json.set("baseline_gpm", baseline[hour]);
  json.set("duration_sec", FLOW_SPIKE_DURATION);
  
  Firebase.pushJSON(firebaseData, "/alerts", json);
  
  flowAnomalyStartTime = 0;  // Reset timer
}

void triggerPressureDropLeak() {
  Serial.println("LEAK DETECTED: PRESSURE DROP (POSSIBLE BURST)");
  Serial.print("  Pressure: ");
  Serial.print(pressurePSI);
  Serial.println(" PSI");
  
  alertActive = true;
  blinkLED(LED_RED, 5);
  tone(BUZZER_PIN, 1500, 500);  // 1.5kHz beep
  
  // Log to Firebase
  FirebaseJson json;
  json.set("timestamp", (long)time(nullptr));
  json.set("type", "PRESSURE_DROP");
  json.set("severity", "HIGH");
  json.set("pressure_psi", pressurePSI);
  json.set("expected_psi", 50);
  
  Firebase.pushJSON(firebaseData, "/alerts", json);
}

void triggerMoistureLeak() {
  Serial.println("EMERGENCY: MOISTURE DETECTED - SHUTTING OFF VALVE!");
  
  String location = "";
  if (moistureKitchen > MOISTURE_THRESHOLD) location += "Kitchen ";
  if (moistureBasement > MOISTURE_THRESHOLD) location += "Basement ";
  if (moistureBathroom > MOISTURE_THRESHOLD) location += "Bathroom";
  
  Serial.print("  Location: ");
  Serial.println(location);
  
  // EMERGENCY SHUTOFF
  shutoffValve();
  
  // Alert indication
  alertActive = true;
  blinkLED(LED_RED, 10);  // Fast blinking
  for (int i = 0; i < 5; i++) {
    tone(BUZZER_PIN, 2000, 200);  // High-pitched alarm
    delay(200);
  }
  
  // Log to Firebase
  FirebaseJson json;
  json.set("timestamp", (long)time(nullptr));
  json.set("type", "MOISTURE_DETECTED");
  json.set("severity", "CRITICAL");
  json.set("location", location);
  json.set("moisture_adc", max({moistureKitchen, moistureBasement, moistureBathroom}));
  
  Firebase.pushJSON(firebaseData, "/alerts", json);
}

// ============================================================================
// VALVE CONTROL
// ============================================================================

void shutoffValve() {
  if (valveOpen) {
    digitalWrite(SOLENOID_VALVE_PIN, LOW);  // Close valve
    valveOpen = false;
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_RED, HIGH);
    
    Serial.println("VALVE CLOSED - Water shutoff activated!");
    delay(500);
  }
}

void openValve() {
  if (!valveOpen) {
    digitalWrite(SOLENOID_VALVE_PIN, HIGH);  // Open valve
    valveOpen = true;
    digitalWrite(LED_RED, LOW);
    digitalWrite(LED_GREEN, HIGH);
    
    Serial.println("VALVE OPENED - Water flow restored!");
    delay(500);
  }
}

// ============================================================================
// FIREBASE OPERATIONS
// ============================================================================

void syncToFirebase() {
  if (!Firebase.connected()) {
    Serial.println("Firebase disconnected, reconnecting...");
    Firebase.begin(FIREBASE_HOST, FIREBASE_AUTH);
    return;
  }
  
  // Create JSON object with current readings
  FirebaseJson json;
  json.set("flow_gpm", flowGPM);
  json.set("pressure_psi", pressurePSI);
  json.set("temp_c", temperatureC);
  json.set("moisture_kitchen", moistureKitchen);
  json.set("moisture_basement", moistureBasement);
  json.set("moisture_bathroom", moistureBathroom);
  json.set("valve_state", valveOpen ? "OPEN" : "CLOSED");
  json.set("baseline_anomaly_percent", baselineAnomalyPercent);
  json.set("timestamp", (long)time(nullptr));
  
  // Update Firebase
  if (Firebase.setJSON(firebaseData, "/currentReading", json)) {
    Serial.println("Firebase sync OK");
  } else {
    Serial.print("Firebase error: ");
    Serial.println(firebaseData.errorReason().c_str());
  }
}

void checkForCommands() {
  if (!Firebase.connected()) return;
  
  // Read command from Firebase
  if (Firebase.getJSON(firebaseData, "/commands/shutoff")) {
    FirebaseJson json;
    json.parseResponse(firebaseData.jsonObject());
    
    String command = json.getString("command", "OPEN");
    
    if (command == "CLOSE") {
      shutoffValve();
    } else if (command == "OPEN") {
      openValve();
    }
  }
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

void connectToWiFi() {
  Serial.print("Connecting to WiFi: ");
  Serial.println(WIFI_SSID);
  
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected!");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi connection failed!");
  }
}

void blinkLED(int pin, int times) {
  for (int i = 0; i < times; i++) {
    digitalWrite(pin, HIGH);
    delay(100);
    digitalWrite(pin, LOW);
    delay(100);
  }
}

void printDebugInfo() {
  Serial.print("Flow: ");
  Serial.print(flowGPM, 2);
  Serial.print(" GPM | Pressure: ");
  Serial.print(pressurePSI, 1);
  Serial.print(" PSI | Temp: ");
  Serial.print(temperatureC, 1);
  Serial.print("°C | Moisture: K=");
  Serial.print(moistureKitchen);
  Serial.print(" B=");
  Serial.print(moistureBasement);
  Serial.print(" Ba=");
  Serial.print(moistureBathroom);
  Serial.print(" | Valve: ");
  Serial.print(valveOpen ? "OPEN" : "CLOSED");
  Serial.println();
}
