# Water Leak Detection App - React Native

Advanced mobile application for real-time monitoring and control of a water leak detection system. Built with React Native + Expo for rapid prototyping and deployment.

## 📱 Features

### Home Dashboard
- **Real-time flow rate** with color-coded alerts (green/yellow/red)
- **Pressure monitoring** (PSI) with normal range indicators
- **Temperature tracking** for cold vs. hot water detection
- **Moisture sensor status** (kitchen, basement, bathroom)
- **Manual valve shutoff** button with confirmation
- **Daily water usage estimates**
- **Flow anomaly percentage** vs. baseline

### Live Sensors Screen
- **Real-time line charts** for flow, pressure, and temperature (last 60 readings)
- **Individual sensor details** with thresholds
- **Moisture sensor ADC values** with dry/wet indicators
- **Summary statistics** (data points, duration, max flow)

### Alert History
- **Chronological log** of all leak detections
- **Filter by severity** (all, high & critical, critical only)
- **Alert details** including type, duration, and severity
- **Summary stats** (total alerts, critical count, high count)

### Settings
- **Flow anomaly multiplier** (1.0-3.0, adjustable sensitivity)
- **Pressure drop threshold** (5-50%)
- **Notification channels** (push, email, SMS toggles)
- **Water rate configuration** (for cost estimation)
- **Device information** display
- **Help & tips** for configuration

## 🚀 Quick Start

### Prerequisites
- Node.js 14+ and npm
- iOS device or Android device (or emulator)
- Firebase project (see `FIREBASE_SETUP.md`)
- Expo account (optional, for cloud builds)

### Installation

1. **Clone or download the project:**
```bash
cd water-leak-app
```

2. **Install dependencies:**
```bash
npm install
```

3. **Configure Firebase:**
   - Follow the steps in `FIREBASE_SETUP.md`
   - Update `src/services/firebaseConfig.js` with your Firebase credentials

4. **Start the development server:**
```bash
npm start
```

5. **Run on device:**
   - iOS: Press `i` in terminal, or scan QR code with Expo Go app
   - Android: Press `a` in terminal, or scan QR code with Expo Go app

## 📋 Project Structure

```
water-leak-app/
├── App.js                          # Root component with navigation
├── package.json                    # Dependencies
├── FIREBASE_SETUP.md              # Firebase configuration guide
├── README.md                       # This file
└── src/
    ├── screens/
    │   ├── HomeScreen.js          # Dashboard with live data
    │   ├── SensorsScreen.js        # Real-time charts
    │   ├── HistoryScreen.js        # Alert log
    │   └── SettingsScreen.js       # Configuration
    └── services/
        ├── firebaseConfig.js       # Firebase initialization
        └── firebaseService.js      # Firebase operations
```

## 🔧 Configuration

### Firebase Credentials
Edit `src/services/firebaseConfig.js`:
```javascript
const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'YOUR_AUTH_DOMAIN',
  projectId: 'YOUR_PROJECT_ID',
  storageBucket: 'YOUR_STORAGE_BUCKET',
  messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
  appId: 'YOUR_APP_ID',
  databaseURL: 'https://YOUR_PROJECT_ID.firebaseio.com',
};
```

### Notification Permissions
The app requests notification permissions on first launch. Make sure to grant permissions:
- **iOS:** Settings > [App Name] > Notifications > Allow Notifications
- **Android:** Settings > Apps > [App Name] > Permissions > Notifications

## 📊 Data Flow

```
ESP32 (Hardware)
    ↓
    └─→ Reads sensors (flow, pressure, temp, moisture)
        └─→ Writes to Firebase Realtime Database
            └─→ App listens for updates
                └─→ Displays in UI + triggers notifications
```

### Firebase Structure
```
/currentReading/         ← Live sensor values (updates every 5 sec)
/baseline/              ← Hour-by-hour baseline pattern
/alerts/                ← Historical alert log
/settings/              ← User configuration
/commands/              ← Commands from app to device
```

## 🎯 Usage Scenarios

### Detecting a Leak
1. **Anomaly detected** in flow rate (>1.5× baseline)
2. **ESP32 logs alert** to Firebase `/alerts` node
3. **App receives notification** instantly
4. **User views alert details** in History tab
5. **User can manually close** valve from app

### Monitoring Daily Usage
1. **Check Home tab** for live flow reading
2. **View Sensors tab** for trend charts
3. **See Settings** for water rate and cost
4. **Review Statistics** for daily usage estimate

### Fine-Tuning Thresholds
1. **Open Settings tab**
2. **Adjust flow multiplier** (lower = more sensitive)
3. **Adjust pressure drop threshold**
4. **Save changes** to Firebase
5. **ESP32 reads new settings** and applies automatically

## 🧪 Testing

### Simulating Test Data (without hardware)
1. Open Firebase Console
2. Manually edit `/currentReading` values
3. App updates in real-time
4. Trigger alerts by editing `/alerts` node

### Running Demo
1. Start app: `npm start`
2. Navigate to Home screen
3. You should see sensor values (or "Loading..." if Firebase not configured)
4. Check console for any Firebase errors

### Debugging
- Open Expo DevTools: `Cmd+D` (iOS) or `Cmd+M` (Android)
- View console logs for Firebase errors
- Check Firebase Console for data structure

## 📱 Supported Platforms

- **iOS 13+**
- **Android 6.0+**
- **Web** (experimental, limited charts)

## 🔐 Security Notes

- **Firebase Test Mode:** Current setup uses public read/write (test mode only)
- **For Production:** Enable Firebase Authentication and secure rules
- **API Keys:** Never commit real API keys; use environment variables
- **Notifications:** Permissions are requested on first app launch

## 🐛 Troubleshooting

### App won't start
```
Error: "Cannot find module 'firebase/database'"
→ Run: npm install
```

### Firebase not connecting
```
Error: "Realtime Database not initialized"
→ Check FIREBASE_SETUP.md for database creation steps
→ Verify firebaseConfig.js has correct credentials
```

### No sensor data appearing
```
Solution 1: Check if ESP32 is writing to Firebase
Solution 2: Verify /currentReading node exists in Firebase Console
Solution 3: Check WiFi connectivity
```

### Notifications not working
```
iOS: Settings > [App] > Notifications > Allow Notifications
Android: Settings > Apps > [App] > Permissions > Notifications
```

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| `react-native` | Native mobile framework |
| `expo` | Rapid prototyping & deployment |
| `@react-navigation/*` | Tab-based navigation |
| `@react-native-firebase/database` | Firebase Realtime DB |
| `react-native-gifted-charts` | Real-time line charts |
| `expo-notifications` | Push notifications |

## 🚀 Build & Deploy

### Expo Cloud Build
```bash
npm install -g eas-cli
eas build --platform ios
eas build --platform android
```

### Local Build
See Expo documentation for local build setup.

## 📝 Notes for Hackathon

- **MVP Focus:** Home + History screens are most critical
- **Charts:** Use gifted-charts for quick implementation
- **Firebase:** Test mode is fine for demo (tighten for production)
- **Notifications:** Push notifications are optional; core app works without them
- **Performance:** App is optimized for <200ms data refresh

## 🎓 Learning Resources

- [React Native Docs](https://reactnative.dev)
- [Expo Docs](https://docs.expo.dev)
- [Firebase Realtime Database](https://firebase.google.com/docs/database)
- [React Navigation](https://reactnavigation.org)

## 📞 Support

For issues:
1. Check `FIREBASE_SETUP.md` for Firebase configuration problems
2. Review console logs in Expo DevTools
3. Check Firebase Console for data structure
4. Verify WiFi and network connectivity

## 📄 License

MIT License - Feel free to use for hackathon or personal projects.

---

**Built for:** 36-hour Water Leak Detection Hackathon  
**Last Updated:** April 2026  
**Status:** Production-Ready MVP
