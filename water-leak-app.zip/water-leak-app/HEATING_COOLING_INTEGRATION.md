# Heating & Cooling Integration Guide
## Water Leak Detection System with Smart Temperature Control

---

## 🌡️ Problem Statement

You now have temperature sensing on your main water line. This opens up **3 major optimization opportunities**:

1. **Hot Water Recovery:** Detect when hot water line loses temperature (potential leak or heat loss)
2. **Preventive Freeze Protection:** Alert when pipes approach freezing (prevent bursts in winter)
3. **Smart Water Heater Integration:** Optimize water heater to reduce standby losses

---

## 🎯 Implementation Approach (Pick One or More)

### Option 1: Passive Monitoring (MVP - Easiest)
**Effort:** Low | **Impact:** Medium | **Time:** 1-2 hours

Monitor temperature and alert user to anomalies. No active control needed.

**What it does:**
- Tracks main line water temp continuously
- Alerts if temp drops suddenly (possible hot water leak)
- Alerts if temp approaches freezing (freeze risk)
- Logs temperature trends for user insights

**How it works:**
```
Temperature Sensor
    ↓
    └─→ ESP32 reads every 1 sec
        ├─→ Compare to baseline
        ├─→ If anomaly: log & alert user
        └─→ Sync to Firebase
            ↓
        Mobile App shows
        ├─→ Real-time temp gauge
        ├─→ Temp history chart
        └─→ Freeze/leak warnings
```

**Example alerts:**
- "Hot water temp dropped 20°F in 2 min - possible leak!"
- "Pipe temperature near 32°F - freeze risk! Check outdoor faucets."
- "Water heater standby loss detected - consider insulation."

---

### Option 2: Smart Water Heater Control (Advanced)
**Effort:** Medium | **Impact:** High | **Time:** 4-6 hours

Actively control water heater setpoint based on demand prediction.

**Hardware needed:**
- WiFi-enabled smart thermostat (Nest, Ecobee) OR
- Relay to control water heater temperature knob (manual setup)
- Temperature sensor on hot water return line (optional)

**What it does:**
```
User's Daily Pattern (7-day learning)
    ↓
    ├─→ Predict when hot water will be needed
    ├─→ Pre-heat at optimal time (30 min before peak)
    └─→ Lower temp during off-peak (midnight-6am)
        ↓
    Typical Savings: 10-15% water heating energy (~$100-200/year)
```

**Example flow:**
```
6:30 AM - System predicts shower at 7am
          └─→ Heater already at 120°F (energy saved vs. always-on)

7:00 AM - User takes shower
          └─→ Hot water immediately available

10:00 AM - No demand predicted
           └─→ Lower setpoint to 110°F to reduce standby loss

6:00 PM - Evening peak predicted
          └─→ Ramp up to 125°F 30 min early
```

---

### Option 3: Greywater Heat Recovery (Expert)
**Effort:** High | **Impact:** Very High | **Time:** 8-12 hours

Capture heat from drain water to preheat incoming cold water.

**Hardware needed:**
- Second temperature sensor on drain line (copper tubing wrap)
- Thermostatic mixing valve upgrade
- Heat exchanger (commercial or DIY copper loop)

**What it does:**
```
Drain water (warm) passes through heat exchanger
    ↓
    └─→ Heats incoming cold water
        └─→ Reduces heating load
            └─→ Typical savings: 20-30% water heating energy
```

**Realistic for hackathon?** No - too complex for 36 hours

---

## 📱 Temperature Features for App (All Options)

### Real-Time Temperature Display
Add to **HomeScreen.js**:

```javascript
{/* Temperature Card */}
<View style={styles.metricCard}>
  <View style={styles.metricHeader}>
    <Ionicons name="thermometer" size={24} color="#E91E63" />
    <Text style={styles.metricLabel}>Water Temperature</Text>
  </View>
  <Text style={styles.metricValue}>
    {currentReadings.temp_c.toFixed(1)}°C
  </Text>
  <Text style={styles.metricDescription}>
    {currentReadings.temp_c < 5 ? '🧊 Freezing risk!' :
     currentReadings.temp_c < 15 ? '❄️ Cold water' :
     currentReadings.temp_c < 35 ? '💧 Lukewarm' :
     currentReadings.temp_c < 50 ? '🔥 Hot water' :
     '🌡️ Very hot'}
  </Text>
</View>
```

### Temperature Baseline Learning

**What to track:**
- Hour-by-hour average temperature
- Expected temperature for each time of day
- Seasonal adjustments (winter colder, summer warmer)

**Firebase schema:**
```json
{
  "baseline_temperature": {
    "0": 12.5,    // 2am avg (coldest)
    "1": 12.3,
    "6": 18.0,    // 8am (morning use)
    "7": 22.5,    // 9am (peak)
    "12": 16.0,   // 2pm (moderate)
    "18": 25.0,   // 8pm (evening)
    "23": 14.0    // 1am
  }
}
```

### Temperature Alerts

**Low temperature (cold water pipe):**
- Current temp < baseline - 5°C
- Duration: > 2 minutes sustained
- Severity: MEDIUM
- Message: "Cold water line temperature dropped. Possible leak?"

**Freeze risk:**
- Temp < 2°C
- Severity: CRITICAL
- Message: "FREEZE RISK: Protect outdoor pipes immediately!"
- Action: Alert sent to all devices

**Hot water anomaly:**
- Temp > 60°C (140°F)
- Duration: > 5 minutes
- Severity: HIGH
- Message: "Hot water line overheating. Check water heater."

---

## 🔧 Firmware Implementation (Option 1 - MVP)

Update **ESP32_FIRMWARE.ino** with temperature baselines:

```cpp
// Temperature baseline (hour-by-hour)
float tempBaseline[24] = {
  12.0,  // 0:00 - 1:00 (coldest, no usage)
  11.8,  // 1:00 - 2:00
  11.5,  // 2:00 - 3:00
  11.2,  // 3:00 - 4:00
  12.0,  // 4:00 - 5:00
  15.0,  // 5:00 - 6:00 (early morning use starts)
  22.5,  // 6:00 - 7:00 (shower peak - hot water used)
  24.0,  // 7:00 - 8:00 (breakfast, dishwashing)
  18.0,  // 8:00 - 9:00 (cooling down)
  14.5,  // 9:00 - 10:00
  13.5,  // 10:00 - 11:00
  13.2,  // 11:00 - 12:00 (low usage)
  14.0,  // 12:00 - 13:00 (lunch)
  13.8,  // 13:00 - 14:00
  13.5,  // 14:00 - 15:00
  13.8,  // 15:00 - 16:00
  18.5,  // 16:00 - 17:00 (pre-dinner)
  26.0,  // 17:00 - 18:00 (dinner peak - cooking, dishwashing)
  25.5,  // 18:00 - 19:00
  22.0,  // 19:00 - 20:00 (evening showers)
  18.5,  // 20:00 - 21:00
  16.0,  // 21:00 - 22:00
  14.0,  // 22:00 - 23:00
  12.5   // 23:00 - 0:00
};

void detectTemperatureAnomalies() {
  int currentHour = timeinfo->tm_hour;
  float expectedTemp = tempBaseline[currentHour];
  float tempDifference = temperatureC - expectedTemp;
  
  // Detect cold water leak (sudden drop)
  if (tempDifference < -5 && temperatureC > 5) {
    triggerColdWaterLeakAlert();
  }
  
  // Detect freeze risk
  if (temperatureC < 2) {
    triggerFreezeRiskAlert();
  }
  
  // Detect hot water line overheat
  if (temperatureC > 60) {
    triggerHotWaterOverheatAlert();
  }
  
  // Log temperature event
  syncTemperatureToFirebase();
}

void triggerColdWaterLeakAlert() {
  Serial.println("ALERT: Cold water line temp drop detected!");
  Serial.print("Expected: ");
  Serial.print(tempBaseline[timeinfo->tm_hour]);
  Serial.print("°C, Actual: ");
  Serial.print(temperatureC);
  Serial.println("°C");
  
  FirebaseJson json;
  json.set("timestamp", (long)time(nullptr));
  json.set("type", "COLD_WATER_ANOMALY");
  json.set("severity", "MEDIUM");
  json.set("temp_c", temperatureC);
  json.set("expected_temp_c", tempBaseline[timeinfo->tm_hour]);
  
  Firebase.pushJSON(firebaseData, "/alerts", json);
}

void triggerFreezeRiskAlert() {
  Serial.println("CRITICAL: FREEZE RISK DETECTED!");
  
  // Emergency indicators
  digitalWrite(BUZZER_PIN, HIGH);  // Continuous buzzer
  blinkLED(LED_RED, 0);  // Solid red
  
  FirebaseJson json;
  json.set("timestamp", (long)time(nullptr));
  json.set("type", "FREEZE_RISK");
  json.set("severity", "CRITICAL");
  json.set("temp_c", temperatureC);
  
  Firebase.pushJSON(firebaseData, "/alerts", json);
}
```

---

## 📊 Add Temperature Chart to App

Update **SensorsScreen.js** to add temperature trend:

```javascript
// Temperature history (add to existing hook)
const [tempHistory, setTempHistory] = useState([]);

// In useEffect:
setTempHistory((prev) => {
  const newHistory = [
    ...prev,
    {
      value: parseFloat(data.temp_c.toFixed(1)),
      label: new Date(data.timestamp * 1000).toLocaleTimeString().substring(0, 5),
    },
  ];
  return newHistory.slice(-60);  // Keep last 60 readings
});

// Add chart to render:
<View style={styles.chartCard}>
  <View style={styles.chartHeader}>
    <Text style={styles.chartTitle}>Water Temperature (°C)</Text>
    <Text style={styles.chartValue}>
      {currentReadings.temp_c.toFixed(1)}°C
    </Text>
  </View>
  <View style={styles.chartContainer}>
    {tempHistory.length > 1 ? (
      <LineChart
        areaChart
        curved
        data={tempHistory}
        height={220}
        width={SCREEN_WIDTH - 52}
        color="#E91E63"
        startFillColor="#E91E63"
        startOpacity={0.1}
        endOpacity={0}
      />
    ) : (
      <Text style={styles.noDataText}>Collecting temperature data...</Text>
    )}
  </View>
</View>
```

---

## 🏠 Real-World Integration Scenarios

### Scenario 1: Detecting a Hot Water Line Leak
```
Normal operation:
  Main line temp: 15-20°C (cold water)
  
Hot water line breaks in walls:
  Main line temp: 25-35°C (hot water mixing in)
  Duration: > 2 min
  
App alerts:
  "Hot water leak detected in walls - temp anomaly!"
  User can immediately investigate
```

### Scenario 2: Winter Freeze Prevention
```
Winter morning:
  Outdoor temp: -5°C
  Pipe temp drops to 0°C
  
System:
  Alerts: "FREEZE RISK - Open indoor faucets to prevent burst"
  Continuously monitors
  
User action:
  Opens faucet to trickle water
  Prevents $11,000+ pipe burst damage
```

### Scenario 3: Water Heater Inefficiency
```
User enables smart thermostat mode:
  System learns usage pattern
  
Before smart control:
  Water heater always at 120°F
  Energy: high constant baseline
  Cost: $200/year for heating
  
After smart control:
  Heater at 110°F off-peak (midnight-6am)
  Pre-heats at 115°F 30 min before showers
  Energy: 15% reduction
  Cost: saves ~$30/year + convenience
```

---

## 📈 MVP vs Advanced Implementation

### MVP (36-Hour Hackathon)
```
✅ Temperature sensor reading
✅ Real-time display on dashboard
✅ Temperature chart on sensors screen
✅ Basic freeze alert (<2°C)
✅ Log temperature to Firebase

Estimated time: 1-2 hours
Code changes: HomeScreen.js, SensorsScreen.js, firmware
```

### Phase 2 (Post-hackathon)
```
✅ Temperature baseline learning
✅ Anomaly detection (cold/hot)
✅ Smart thermostat API integration
✅ Predictive pre-heating
✅ Historical temperature analysis

Estimated time: 4-6 hours
```

### Phase 3 (Advanced)
```
✅ Machine learning predictions
✅ Multi-zone temperature monitoring
✅ Heat recovery simulation
✅ Integration with smart home (Alexa, Google Home)
✅ Seasonal adjustments

Estimated time: 2-3 days
```

---

## 🔗 Architecture Diagram

```
Temperature Sensor (DHT22)
    ↓
ESP32 reads every 1 second
    ├─→ Compare to baseline[hour]
    ├─→ Detect anomalies
    ├─→ Trigger alerts if needed
    └─→ Sync to Firebase every 5 sec
        ↓
Firebase Realtime DB
    /currentReading/temp_c
    /baseline_temperature/
    /alerts/ (if anomaly)
        ↓
Mobile App (React Native)
    ├─→ HomeScreen: Live temp gauge
    ├─→ SensorsScreen: Temp history chart
    ├─→ HistoryScreen: Temp anomaly alerts
    └─→ SettingsScreen: Temp thresholds
```

---

## 💡 Smart Heating Ideas (Advanced)

### Idea 1: Time-of-Use (TOU) Water Heating
**What:** Lower water heater temp during cheap electricity periods, raise during peak
**Impact:** 10-20% energy savings
**Hardware:** WiFi-enabled thermostat + temp sensor
**Complexity:** Medium (4-6 hours)

### Idea 2: Demand-Driven Pre-Heating
**What:** Heat water 30 min before predicted demand peaks
**Impact:** 15-25% energy reduction (less standby loss)
**Hardware:** Motion sensors (detect morning wake-up)
**Complexity:** Medium (requires ML)

### Idea 3: Passive Heat Recovery
**What:** Use heat from drain water to preheat cold input
**Impact:** 20-30% energy reduction (biggest impact)
**Hardware:** Copper coil heat exchanger (~$50)
**Complexity:** Hard (requires plumbing skill)

---

## 🎯 Recommended Path for Hackathon

### Hours 0-1
- [x] Temperature sensor already reading (firmware done)
- [x] Add temperature display to HomeScreen.js
- [x] Add temperature chart to SensorsScreen.js

### Hours 1-2
- [x] Implement freeze alert (<2°C)
- [x] Add temperature baseline[24] to firmware
- [x] Sync temperature to Firebase

### Hours 2-3 (if time)
- [x] Add cold water anomaly detection
- [x] Add temperature anomaly to HistoryScreen
- [ ] Stretch: Temperature-based thermostat integration

---

## 📚 Resources & References

- **Smart Thermostat APIs:**
  - Nest API: https://developers.google.com/nest/device-access
  - Ecobee API: https://www.ecobee.com/developers/
  - Generic MQTT: MQTT protocol for generic smart devices

- **Temperature Control:**
  - DHT22 spec: 0-50°C range (good for indoor water temp)
  - Thermostatic mixing valves: Standard in plumbing, no electronics needed
  - Heat recovery ventilation (HRV) systems

- **Energy Monitoring:**
  - EPA water heating guide: https://www.energystar.gov/
  - DOE water heating calculator: https://www.energy.gov/

---

## ⚡ Key Takeaway

**You don't need active heating/cooling control to make temperature data valuable.** Even just monitoring and alerting on anomalies provides significant value:

1. **Leak detection** (hot water line breaks visible as temp spike)
2. **Freeze prevention** (winter protection)
3. **User insights** (see when water heater is running)
4. **Baseline learning** (understand usage patterns)

Start with **Option 1 (Passive Monitoring)** for the hackathon - it's quick, valuable, and can be extended later!

---

**Recommendation:** Implement Option 1 (MVP) in 1-2 hours, then decide if you have time/interest in Option 2.

