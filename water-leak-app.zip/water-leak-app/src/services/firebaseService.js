import { 
  ref, 
  onValue, 
  update, 
  child, 
  get,
  query,
  orderByChild,
  limitToLast
} from 'firebase/database';
import { database } from './firebaseConfig';

/**
 * Listen to current sensor readings from Firebase
 * @param {Function} callback - Function to call when data updates
 * @returns {Function} Unsubscribe function
 */
export const subscribeToCurrentReadings = (callback) => {
  const readingsRef = ref(database, 'currentReading');
  
  const unsubscribe = onValue(readingsRef, (snapshot) => {
    if (snapshot.exists()) {
      callback(snapshot.val());
    } else {
      console.log('No current readings available');
      callback(null);
    }
  }, (error) => {
    console.error('Error reading current sensor data:', error);
  });

  return unsubscribe;
};

/**
 * Listen to baseline data from Firebase
 * @param {Function} callback - Function to call when baseline updates
 * @returns {Function} Unsubscribe function
 */
export const subscribeToBaseline = (callback) => {
  const baselineRef = ref(database, 'baseline');
  
  const unsubscribe = onValue(baselineRef, (snapshot) => {
    if (snapshot.exists()) {
      callback(snapshot.val());
    } else {
      console.log('No baseline available');
      callback({});
    }
  }, (error) => {
    console.error('Error reading baseline data:', error);
  });

  return unsubscribe;
};

/**
 * Listen to alert history from Firebase
 * @param {Function} callback - Function to call when alerts update
 * @returns {Function} Unsubscribe function
 */
export const subscribeToAlerts = (callback) => {
  const alertsRef = ref(database, 'alerts');
  
  const unsubscribe = onValue(alertsRef, (snapshot) => {
    if (snapshot.exists()) {
      const alertsData = snapshot.val();
      // Convert to array and sort by timestamp (newest first)
      const alertsArray = Object.keys(alertsData).map((key) => ({
        id: key,
        ...alertsData[key],
      }));
      alertsArray.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      callback(alertsArray);
    } else {
      console.log('No alerts available');
      callback([]);
    }
  }, (error) => {
    console.error('Error reading alert data:', error);
  });

  return unsubscribe;
};

/**
 * Listen to settings from Firebase
 * @param {Function} callback - Function to call when settings update
 * @returns {Function} Unsubscribe function
 */
export const subscribeToSettings = (callback) => {
  const settingsRef = ref(database, 'settings');
  
  const unsubscribe = onValue(settingsRef, (snapshot) => {
    if (snapshot.exists()) {
      callback(snapshot.val());
    } else {
      // Return default settings
      callback({
        flow_threshold_multiplier: 1.5,
        pressure_drop_threshold: 15,
        notification_channels: ['push'],
        electricity_rate: 0.004, // $ per gallon
      });
    }
  }, (error) => {
    console.error('Error reading settings:', error);
  });

  return unsubscribe;
};

/**
 * Update settings in Firebase
 * @param {Object} newSettings - Settings to update
 */
export const updateSettings = async (newSettings) => {
  try {
    const settingsRef = ref(database, 'settings');
    await update(settingsRef, newSettings);
    console.log('Settings updated successfully');
  } catch (error) {
    console.error('Error updating settings:', error);
    throw error;
  }
};

/**
 * Trigger manual shutoff via Firebase
 * @param {String} command - 'OPEN' or 'CLOSE'
 */
export const sendShutoffCommand = async (command) => {
  try {
    const commandRef = ref(database, 'commands/shutoff');
    await update(commandRef, {
      command: command,
      timestamp: Date.now(),
      requested_by: 'app',
    });
    console.log(`Shutoff command sent: ${command}`);
  } catch (error) {
    console.error('Error sending shutoff command:', error);
    throw error;
  }
};

/**
 * Fetch historical readings for a time range (optional - for advanced analytics)
 */
export const fetchReadingsHistory = async (limit = 100) => {
  try {
    const historyRef = ref(database, 'readingsHistory');
    const historyQuery = query(
      historyRef,
      orderByChild('timestamp'),
      limitToLast(limit)
    );
    
    const snapshot = await get(historyQuery);
    if (snapshot.exists()) {
      return snapshot.val();
    } else {
      return {};
    }
  } catch (error) {
    console.error('Error fetching readings history:', error);
    throw error;
  }
};

/**
 * Calculate water usage statistics
 */
export const calculateWaterStats = (readings) => {
  if (!readings) return { daily_usage_gal: 0, estimated_cost: 0 };
  
  // Simple calculation: sum of flow readings * time interval
  // In production, you'd want more sophisticated tracking
  const flow_gpm = readings.flow_gpm || 0;
  const electricity_rate = readings.electricity_rate || 0.004;
  
  // Rough estimate: assume average household uses 80-100 gal/day
  // This is a placeholder; real calculation would integrate over 24 hours
  const daily_usage_gal = flow_gpm * 60 * 24 * 0.01; // Very rough estimate
  const estimated_cost = daily_usage_gal * electricity_rate;
  
  return {
    daily_usage_gal: Math.round(daily_usage_gal * 100) / 100,
    estimated_cost: Math.round(estimated_cost * 100) / 100,
  };
};

export default {
  subscribeToCurrentReadings,
  subscribeToBaseline,
  subscribeToAlerts,
  subscribeToSettings,
  updateSettings,
  sendShutoffCommand,
  fetchReadingsHistory,
  calculateWaterStats,
};
