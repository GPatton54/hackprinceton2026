import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  FlatList,
  TouchableOpacity,
  Alert as RNAlert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { subscribeToAlerts } from '../services/firebaseService';

const HistoryScreen = () => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // 'all', 'high', 'critical'

  useEffect(() => {
    setLoading(true);

    // Subscribe to alerts
    const unsubscribeAlerts = subscribeToAlerts((data) => {
      setAlerts(data);
      setLoading(false);
    });

    return () => {
      unsubscribeAlerts();
    };
  }, []);

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'CRITICAL':
        return '#F44336';
      case 'HIGH':
        return '#FF9800';
      case 'MEDIUM':
        return '#FFC107';
      default:
        return '#4CAF50';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'CRITICAL':
        return 'alert-circle';
      case 'HIGH':
        return 'warning';
      case 'MEDIUM':
        return 'information-circle';
      default:
        return 'checkmark-circle';
    }
  };

  const getAlertDescription = (alert) => {
    switch (alert.type) {
      case 'FLOW_SPIKE':
        return `Flow spike detected: ${alert.flow_gpm.toFixed(2)} GPM (baseline: ${alert.baseline_gpm.toFixed(2)} GPM)`;
      case 'PRESSURE_DROP':
        return `Pressure drop detected: ${alert.pressure_psi.toFixed(1)} PSI`;
      case 'MOISTURE_DETECTED':
        return `Water detected at: ${alert.location}`;
      default:
        return 'Alert triggered';
    }
  };

  const formatTime = (timestamp) => {
    if (!timestamp) return 'Unknown';
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  const filteredAlerts = alerts.filter((alert) => {
    if (filter === 'all') return true;
    if (filter === 'high') return alert.severity === 'HIGH' || alert.severity === 'CRITICAL';
    if (filter === 'critical') return alert.severity === 'CRITICAL';
    return true;
  });

  const handleAlertPress = (alert) => {
    RNAlert.alert(
      `${alert.severity} Alert`,
      getAlertDescription(alert),
      [
        {
          text: 'Dismiss',
          onPress: () => console.log('Dismissed'),
          style: 'cancel',
        },
        {
          text: 'View Details',
          onPress: () => {
            RNAlert.alert('Alert Details', JSON.stringify(alert, null, 2));
          },
        },
      ]
    );
  };

  const renderAlertItem = ({ item: alert, index }) => {
    const duration = alert.duration_sec ? `${Math.round(alert.duration_sec)}s` : 'ongoing';

    return (
      <TouchableOpacity
        style={styles.alertItem}
        onPress={() => handleAlertPress(alert)}
      >
        <View
          style={[
            styles.alertIconContainer,
            { backgroundColor: getSeverityColor(alert.severity) },
          ]}
        >
          <Ionicons
            name={getSeverityIcon(alert.severity)}
            size={24}
            color="#fff"
          />
        </View>
        <View style={styles.alertContent}>
          <View style={styles.alertHeader}>
            <Text style={styles.alertSeverity}>{alert.severity}</Text>
            <Text style={styles.alertType}>{alert.type}</Text>
          </View>
          <Text style={styles.alertDescription}>
            {getAlertDescription(alert)}
          </Text>
          <View style={styles.alertFooter}>
            <Text style={styles.alertTime}>{formatTime(alert.timestamp)}</Text>
            <Text style={styles.alertDuration}>Duration: {duration}</Text>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={20} color="#ccc" />
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Loading alerts...</Text>
      </View>
    );
  }

  const criticalCount = alerts.filter((a) => a.severity === 'CRITICAL').length;
  const highCount = alerts.filter((a) => a.severity === 'HIGH').length;

  return (
    <View style={styles.container}>
      {/* Summary Stats */}
      <View style={styles.summaryCard}>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>Total Alerts</Text>
          <Text style={styles.summaryValue}>{alerts.length}</Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>Critical</Text>
          <Text style={[styles.summaryValue, { color: '#F44336' }]}>
            {criticalCount}
          </Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>High</Text>
          <Text style={[styles.summaryValue, { color: '#FF9800' }]}>
            {highCount}
          </Text>
        </View>
      </View>

      {/* Filter Buttons */}
      <View style={styles.filterContainer}>
        <TouchableOpacity
          style={[
            styles.filterButton,
            filter === 'all' && styles.filterButtonActive,
          ]}
          onPress={() => setFilter('all')}
        >
          <Text
            style={[
              styles.filterButtonText,
              filter === 'all' && styles.filterButtonTextActive,
            ]}
          >
            All ({alerts.length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.filterButton,
            filter === 'high' && styles.filterButtonActive,
          ]}
          onPress={() => setFilter('high')}
        >
          <Text
            style={[
              styles.filterButtonText,
              filter === 'high' && styles.filterButtonTextActive,
            ]}
          >
            High & Critical ({criticalCount + highCount})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.filterButton,
            filter === 'critical' && styles.filterButtonActive,
          ]}
          onPress={() => setFilter('critical')}
        >
          <Text
            style={[
              styles.filterButtonText,
              filter === 'critical' && styles.filterButtonTextActive,
            ]}
          >
            Critical ({criticalCount})
          </Text>
        </TouchableOpacity>
      </View>

      {/* Alerts List */}
      {filteredAlerts.length > 0 ? (
        <FlatList
          data={filteredAlerts}
          renderItem={renderAlertItem}
          keyExtractor={(item, index) => item.id || index.toString()}
          scrollEnabled={false}
          style={styles.alertsList}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Ionicons name="checkmark-circle" size={48} color="#4CAF50" />
          <Text style={styles.emptyText}>
            {filter === 'all'
              ? 'No alerts yet. System is running normally!'
              : `No ${filter} alerts.`}
          </Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    paddingHorizontal: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  summaryCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    marginVertical: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    overflow: 'hidden',
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 16,
    borderRightWidth: 1,
    borderRightColor: '#f0f0f0',
  },
  summaryItem__last: {
    borderRightWidth: 0,
  },
  summaryLabel: {
    fontSize: 11,
    color: '#999',
    marginBottom: 6,
    fontWeight: '500',
  },
  summaryValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#333',
  },
  filterContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    alignItems: 'center',
  },
  filterButtonActive: {
    backgroundColor: '#007AFF',
    borderColor: '#007AFF',
  },
  filterButtonText: {
    fontSize: 11,
    color: '#666',
    fontWeight: '500',
  },
  filterButtonTextActive: {
    color: '#fff',
  },
  alertsList: {
    marginBottom: 16,
  },
  alertItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 12,
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  alertIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  alertContent: {
    flex: 1,
  },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    gap: 8,
  },
  alertSeverity: {
    fontSize: 12,
    fontWeight: '700',
    color: '#333',
  },
  alertType: {
    fontSize: 11,
    color: '#999',
    fontStyle: 'italic',
  },
  alertDescription: {
    fontSize: 13,
    color: '#666',
    marginBottom: 6,
  },
  alertFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  alertTime: {
    fontSize: 10,
    color: '#999',
  },
  alertDuration: {
    fontSize: 10,
    color: '#999',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom: 40,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
});

export default HistoryScreen;
