import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  subscribeToCurrentReadings,
  subscribeToSettings,
  sendShutoffCommand,
  calculateWaterStats,
} from '../services/firebaseService';

const HomeScreen = () => {
  const [currentReadings, setCurrentReadings] = useState(null);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [alertActive, setAlertActive] = useState(false);
  const [shutoffLoading, setShutoffLoading] = useState(false);

  useEffect(() => {
    setLoading(true);

    // Subscribe to current readings
    const unsubscribeReadings = subscribeToCurrentReadings((data) => {
      setCurrentReadings(data);
      setLoading(false);
      // Check if there's an active alert
      if (data && data.baseline_anomaly_percent > 50) {
        setAlertActive(true);
      }
    });

    // Subscribe to settings
    const unsubscribeSettings = subscribeToSettings((data) => {
      setSettings(data);
    });

    // Cleanup subscriptions on unmount
    return () => {
      unsubscribeReadings();
      unsubscribeSettings();
    };
  }, []);

  const handleShutoff = async (command) => {
    Alert.alert(
      `${command === 'CLOSE' ? 'Close' : 'Open'} Water Valve?`,
      `Are you sure you want to ${command === 'CLOSE' ? 'shut off' : 'turn on'} the water valve?`,
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancelled'),
          style: 'cancel',
        },
        {
          text: 'Confirm',
          onPress: async () => {
            setShutoffLoading(true);
            try {
              await sendShutoffCommand(command);
              Alert.alert(
                'Success',
                `Valve ${command === 'CLOSE' ? 'closed' : 'opened'} successfully`
              );
            } catch (error) {
              Alert.alert('Error', 'Failed to send shutoff command');
            } finally {
              setShutoffLoading(false);
            }
          },
          style: command === 'CLOSE' ? 'destructive' : 'default',
        },
      ]
    );
  };

  const getFlowColor = (flow) => {
    if (flow < 1) return '#4CAF50'; // Green
    if (flow < 2.5) return '#FFC107'; // Yellow
    return '#F44336'; // Red
  };

  const getFlowDescription = (flow) => {
    if (flow < 0.5) return 'Minimal flow';
    if (flow < 1) return 'Low flow';
    if (flow < 2.5) return 'Normal flow';
    if (flow < 4) return 'High flow';
    return 'Very high flow';
  };

  const waterStats = currentReadings ? calculateWaterStats(currentReadings) : null;

  if (loading || !currentReadings) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Loading sensor data...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      {/* Alert Banner */}
      {alertActive && (
        <View style={styles.alertBanner}>
          <Ionicons name="alert-circle" size={24} color="#fff" />
          <Text style={styles.alertText}>
            Possible leak detected! Check sensors or close valve.
          </Text>
        </View>
      )}

      {/* Valve Status */}
      <View style={styles.valveStatusCard}>
        <View style={styles.valveStatusContent}>
          <Ionicons
            name={currentReadings.valve_state === 'OPEN' ? 'water' : 'lock-closed'}
            size={32}
            color={currentReadings.valve_state === 'OPEN' ? '#4CAF50' : '#F44336'}
          />
          <View style={styles.valveStatusText}>
            <Text style={styles.valveStatusLabel}>Valve Status</Text>
            <Text
              style={[
                styles.valveStatusValue,
                {
                  color:
                    currentReadings.valve_state === 'OPEN'
                      ? '#4CAF50'
                      : '#F44336',
                },
              ]}
            >
              {currentReadings.valve_state}
            </Text>
          </View>
        </View>
        <View style={styles.valveButtons}>
          <TouchableOpacity
            style={[styles.valveButton, styles.openButton]}
            onPress={() => handleShutoff('OPEN')}
            disabled={shutoffLoading}
          >
            <Text style={styles.buttonText}>OPEN</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.valveButton, styles.closeButton]}
            onPress={() => handleShutoff('CLOSE')}
            disabled={shutoffLoading}
          >
            <Text style={styles.buttonText}>CLOSE</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Flow Rate */}
      <View style={styles.metricCard}>
        <View style={styles.metricHeader}>
          <Ionicons name="water" size={24} color="#2196F3" />
          <Text style={styles.metricLabel}>Flow Rate</Text>
        </View>
        <Text
          style={[styles.metricValue, { color: getFlowColor(currentReadings.flow_gpm) }]}
        >
          {currentReadings.flow_gpm.toFixed(2)} GPM
        </Text>
        <Text style={styles.metricDescription}>
          {getFlowDescription(currentReadings.flow_gpm)}
        </Text>
      </View>

      {/* Pressure */}
      <View style={styles.metricCard}>
        <View style={styles.metricHeader}>
          <Ionicons name="pulse" size={24} color="#FF9800" />
          <Text style={styles.metricLabel}>Pressure</Text>
        </View>
        <Text style={styles.metricValue}>{currentReadings.pressure_psi.toFixed(1)} PSI</Text>
        <Text style={styles.metricDescription}>
          {currentReadings.pressure_psi > 45 && currentReadings.pressure_psi < 80
            ? 'Normal'
            : 'Check system'}
        </Text>
      </View>

      {/* Temperature */}
      <View style={styles.metricCard}>
        <View style={styles.metricHeader}>
          <Ionicons name="thermometer" size={24} color="#E91E63" />
          <Text style={styles.metricLabel}>Temperature</Text>
        </View>
        <Text style={styles.metricValue}>{currentReadings.temp_c.toFixed(1)}°C</Text>
        <Text style={styles.metricDescription}>
          {currentReadings.temp_c < 20 ? 'Cold water' : 'Warm water'}
        </Text>
      </View>

      {/* Moisture Sensors Status */}
      <View style={styles.moistureCard}>
        <View style={styles.metricHeader}>
          <Ionicons name="droplet" size={24} color="#673AB7" />
          <Text style={styles.metricLabel}>Moisture Sensors</Text>
        </View>
        <View style={styles.moistureGrid}>
          <View style={styles.moistureSensor}>
            <Text style={styles.moistureLabel}>Kitchen</Text>
            <Text
              style={[
                styles.moistureValue,
                {
                  color: currentReadings.moisture_kitchen > 400 ? '#F44336' : '#4CAF50',
                },
              ]}
            >
              {currentReadings.moisture_kitchen}
            </Text>
            <Text style={styles.moistureStatus}>
              {currentReadings.moisture_kitchen > 400 ? 'WET' : 'DRY'}
            </Text>
          </View>
          <View style={styles.moistureSensor}>
            <Text style={styles.moistureLabel}>Basement</Text>
            <Text
              style={[
                styles.moistureValue,
                {
                  color: currentReadings.moisture_basement > 400 ? '#F44336' : '#4CAF50',
                },
              ]}
            >
              {currentReadings.moisture_basement}
            </Text>
            <Text style={styles.moistureStatus}>
              {currentReadings.moisture_basement > 400 ? 'WET' : 'DRY'}
            </Text>
          </View>
          <View style={styles.moistureSensor}>
            <Text style={styles.moistureLabel}>Bathroom</Text>
            <Text
              style={[
                styles.moistureValue,
                {
                  color: currentReadings.moisture_bathroom > 400 ? '#F44336' : '#4CAF50',
                },
              ]}
            >
              {currentReadings.moisture_bathroom}
            </Text>
            <Text style={styles.moistureStatus}>
              {currentReadings.moisture_bathroom > 400 ? 'WET' : 'DRY'}
            </Text>
          </View>
        </View>
      </View>

      {/* Daily Stats */}
      {waterStats && (
        <View style={styles.statsCard}>
          <Text style={styles.statsTitle}>Today's Usage</Text>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Water Used</Text>
              <Text style={styles.statValue}>{waterStats.daily_usage_gal} gal</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statLabel}>Estimated Cost</Text>
              <Text style={styles.statValue}>${waterStats.estimated_cost.toFixed(2)}</Text>
            </View>
          </View>
        </View>
      )}

      {/* Baseline Anomaly */}
      <View style={styles.anomalyCard}>
        <Text style={styles.anomalyLabel}>Flow Anomaly</Text>
        <Text
          style={[
            styles.anomalyValue,
            {
              color:
                currentReadings.baseline_anomaly_percent > 50
                  ? '#F44336'
                  : '#4CAF50',
            },
          ]}
        >
          {Math.round(currentReadings.baseline_anomaly_percent || 0)}%
        </Text>
        <Text style={styles.anomalyDescription}>
          vs. baseline for this hour
        </Text>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Last updated: {new Date(currentReadings.timestamp * 1000).toLocaleTimeString()}
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  alertBanner: {
    flexDirection: 'row',
    backgroundColor: '#F44336',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    alignItems: 'center',
  },
  alertText: {
    color: '#fff',
    marginLeft: 12,
    flex: 1,
    fontWeight: '500',
  },
  valveStatusCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  valveStatusContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  valveStatusText: {
    marginLeft: 12,
    flex: 1,
  },
  valveStatusLabel: {
    fontSize: 12,
    color: '#999',
    marginBottom: 4,
  },
  valveStatusValue: {
    fontSize: 20,
    fontWeight: '700',
  },
  valveButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  valveButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  openButton: {
    backgroundColor: '#4CAF50',
  },
  closeButton: {
    backgroundColor: '#F44336',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  metricCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  metricHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  metricLabel: {
    marginLeft: 8,
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  metricValue: {
    fontSize: 28,
    fontWeight: '700',
    marginBottom: 4,
  },
  metricDescription: {
    fontSize: 12,
    color: '#999',
  },
  moistureCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  moistureGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  moistureSensor: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#f5f5f5',
  },
  moistureLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 6,
    fontWeight: '500',
  },
  moistureValue: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  moistureStatus: {
    fontSize: 11,
    color: '#999',
    fontWeight: '600',
  },
  statsCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  statsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
  },
  statLabel: {
    fontSize: 11,
    color: '#999',
    marginBottom: 6,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  anomalyCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  anomalyLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 6,
  },
  anomalyValue: {
    fontSize: 28,
    fontWeight: '700',
    marginBottom: 4,
  },
  anomalyDescription: {
    fontSize: 12,
    color: '#999',
  },
  footer: {
    paddingVertical: 12,
    alignItems: 'center',
    marginBottom: 20,
  },
  footerText: {
    fontSize: 11,
    color: '#999',
  },
});

export default HomeScreen;
