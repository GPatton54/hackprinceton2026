import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { LineChart } from 'react-native-gifted-charts';
import {
  subscribeToCurrentReadings,
  subscribeToBaseline,
} from '../services/firebaseService';

const SCREEN_WIDTH = Dimensions.get('window').width;

const SensorsScreen = () => {
  const [currentReadings, setCurrentReadings] = useState(null);
  const [baseline, setBaseline] = useState({});
  const [loading, setLoading] = useState(true);
  const [flowHistory, setFlowHistory] = useState([]);
  const [pressureHistory, setPressureHistory] = useState([]);
  const [tempHistory, setTempHistory] = useState([]);

  useEffect(() => {
    setLoading(true);

    // Subscribe to current readings
    const unsubscribeReadings = subscribeToCurrentReadings((data) => {
      if (data) {
        setCurrentReadings(data);

        // Add to history (keep last 60 readings)
        setFlowHistory((prev) => {
          const newHistory = [
            ...prev,
            {
              value: parseFloat(data.flow_gpm.toFixed(2)),
              label: new Date(data.timestamp * 1000).toLocaleTimeString().substring(0, 5),
            },
          ];
          return newHistory.slice(-60);
        });

        setPressureHistory((prev) => {
          const newHistory = [
            ...prev,
            {
              value: parseFloat(data.pressure_psi.toFixed(1)),
              label: new Date(data.timestamp * 1000).toLocaleTimeString().substring(0, 5),
            },
          ];
          return newHistory.slice(-60);
        });

        setTempHistory((prev) => {
          const newHistory = [
            ...prev,
            {
              value: parseFloat(data.temp_c.toFixed(1)),
              label: new Date(data.timestamp * 1000).toLocaleTimeString().substring(0, 5),
            },
          ];
          return newHistory.slice(-60);
        });

        setLoading(false);
      }
    });

    // Subscribe to baseline
    const unsubscribeBaseline = subscribeToBaseline((data) => {
      setBaseline(data);
    });

    return () => {
      unsubscribeReadings();
      unsubscribeBaseline();
    };
  }, []);

  if (loading || !currentReadings) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Loading sensors...</Text>
      </View>
    );
  }

  const baselineForHour = baseline[new Date().getHours()] || 0.1;

  return (
    <ScrollView style={styles.container}>
      {/* Flow Rate Chart */}
      <View style={styles.chartCard}>
        <View style={styles.chartHeader}>
          <Text style={styles.chartTitle}>Flow Rate (GPM)</Text>
          <Text style={styles.chartValue}>
            {currentReadings.flow_gpm.toFixed(2)} GPM
          </Text>
        </View>
        <View style={styles.chartContainer}>
          {flowHistory.length > 1 ? (
            <LineChart
              areaChart
              curved
              data={flowHistory}
              height={220}
              width={SCREEN_WIDTH - 52}
              showVerticalLines
              verticalLinesColor="#e0e0e0"
              color="#2196F3"
              startFillColor="#2196F3"
              startOpacity={0.1}
              endOpacity={0}
              xAxisColor="#e0e0e0"
              yAxisColor="#e0e0e0"
              yAxisLabelWidth={40}
              hideRules={false}
              rulesColor="#e0e0e0"
              yAxisTextStyle={{fontSize: 10, color: '#666'}}
              xAxisLabelTextStyle={{fontSize: 10, color: '#666', marginTop: 8}}
            />
          ) : (
            <Text style={styles.noDataText}>Collecting data...</Text>
          )}
        </View>
        <View style={styles.chartInfo}>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Baseline (this hour)</Text>
            <Text style={styles.infoValue}>{baselineForHour.toFixed(2)} GPM</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Anomaly</Text>
            <Text style={[
              styles.infoValue,
              { color: currentReadings.baseline_anomaly_percent > 50 ? '#F44336' : '#4CAF50' }
            ]}>
              {Math.round(currentReadings.baseline_anomaly_percent || 0)}%
            </Text>
          </View>
        </View>
      </View>

      {/* Pressure Chart */}
      <View style={styles.chartCard}>
        <View style={styles.chartHeader}>
          <Text style={styles.chartTitle}>Pressure (PSI)</Text>
          <Text style={styles.chartValue}>
            {currentReadings.pressure_psi.toFixed(1)} PSI
          </Text>
        </View>
        <View style={styles.chartContainer}>
          {pressureHistory.length > 1 ? (
            <LineChart
              areaChart
              curved
              data={pressureHistory}
              height={220}
              width={SCREEN_WIDTH - 52}
              showVerticalLines
              verticalLinesColor="#e0e0e0"
              color="#FF9800"
              startFillColor="#FF9800"
              startOpacity={0.1}
              endOpacity={0}
              xAxisColor="#e0e0e0"
              yAxisColor="#e0e0e0"
              yAxisLabelWidth={40}
              hideRules={false}
              rulesColor="#e0e0e0"
              yAxisTextStyle={{fontSize: 10, color: '#666'}}
              xAxisLabelTextStyle={{fontSize: 10, color: '#666', marginTop: 8}}
            />
          ) : (
            <Text style={styles.noDataText}>Collecting data...</Text>
          )}
        </View>
        <View style={styles.chartInfo}>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Normal Range</Text>
            <Text style={styles.infoValue}>45 - 80 PSI</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Status</Text>
            <Text style={[
              styles.infoValue,
              { color: currentReadings.pressure_psi > 45 && currentReadings.pressure_psi < 80 ? '#4CAF50' : '#F44336' }
            ]}>
              {currentReadings.pressure_psi > 45 && currentReadings.pressure_psi < 80 ? 'Normal' : 'Alert'}
            </Text>
          </View>
        </View>
      </View>

      {/* Temperature Chart */}
      <View style={styles.chartCard}>
        <View style={styles.chartHeader}>
          <Text style={styles.chartTitle}>Temperature (°C)</Text>
          <Text style={styles.chartValue}>
            {currentReadings.temp_c.toFixed(1)}°C
          </Text>
        </View>
        <View style={styles.chartContainer}>
          {tempHistory.length > 1 ? (
            <LineChart
              areaChart
              curved
              data={tempHistory}
              height={220}
              width={SCREEN_WIDTH - 52}
              showVerticalLines
              verticalLinesColor="#e0e0e0"
              color="#E91E63"
              startFillColor="#E91E63"
              startOpacity={0.1}
              endOpacity={0}
              xAxisColor="#e0e0e0"
              yAxisColor="#e0e0e0"
              yAxisLabelWidth={40}
              hideRules={false}
              rulesColor="#e0e0e0"
              yAxisTextStyle={{fontSize: 10, color: '#666'}}
              xAxisLabelTextStyle={{fontSize: 10, color: '#666', marginTop: 8}}
            />
          ) : (
            <Text style={styles.noDataText}>Collecting data...</Text>
          )}
        </View>
        <View style={styles.chartInfo}>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Line Type</Text>
            <Text style={styles.infoValue}>{currentReadings.temp_c < 20 ? 'Cold' : 'Hot'}</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Readings</Text>
            <Text style={styles.infoValue}>{tempHistory.length}</Text>
          </View>
        </View>
      </View>

      {/* Moisture Sensors Details */}
      <View style={styles.chartCard}>
        <Text style={styles.chartTitle}>Moisture Sensors (ADC Units)</Text>
        <View style={styles.moistureDetailGrid}>
          <View style={styles.moistureDetailItem}>
            <Text style={styles.moistureDetailLabel}>Kitchen</Text>
            <Text
              style={[
                styles.moistureDetailValue,
                { color: currentReadings.moisture_kitchen > 400 ? '#F44336' : '#4CAF50' }
              ]}
            >
              {currentReadings.moisture_kitchen}
            </Text>
            <Text style={styles.moistureDetailStatus}>
              {currentReadings.moisture_kitchen > 400 ? '⚠️ WET' : '✓ DRY'}
            </Text>
          </View>
          <View style={styles.moistureDetailItem}>
            <Text style={styles.moistureDetailLabel}>Basement</Text>
            <Text
              style={[
                styles.moistureDetailValue,
                { color: currentReadings.moisture_basement > 400 ? '#F44336' : '#4CAF50' }
              ]}
            >
              {currentReadings.moisture_basement}
            </Text>
            <Text style={styles.moistureDetailStatus}>
              {currentReadings.moisture_basement > 400 ? '⚠️ WET' : '✓ DRY'}
            </Text>
          </View>
          <View style={styles.moistureDetailItem}>
            <Text style={styles.moistureDetailLabel}>Bathroom</Text>
            <Text
              style={[
                styles.moistureDetailValue,
                { color: currentReadings.moisture_bathroom > 400 ? '#F44336' : '#4CAF50' }
              ]}
            >
              {currentReadings.moisture_bathroom}
            </Text>
            <Text style={styles.moistureDetailStatus}>
              {currentReadings.moisture_bathroom > 400 ? '⚠️ WET' : '✓ DRY'}
            </Text>
          </View>
        </View>
        <Text style={styles.thresholdNote}>
          Threshold: ~400 ADC (adjust in settings)
        </Text>
      </View>

      {/* Summary Stats */}
      <View style={styles.chartCard}>
        <Text style={styles.chartTitle}>Summary</Text>
        <View style={styles.summaryGrid}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Data Points</Text>
            <Text style={styles.summaryValue}>{flowHistory.length}</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Duration</Text>
            <Text style={styles.summaryValue}>
              {Math.round(flowHistory.length / 12)} min
            </Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Max Flow</Text>
            <Text style={styles.summaryValue}>
              {flowHistory.length > 0
                ? Math.max(...flowHistory.map((d) => d.value)).toFixed(2)
                : '0.00'}{' '}
              GPM
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.footer} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  chartCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  chartHeader: {
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  chartValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#007AFF',
  },
  chartContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  noDataText: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    paddingVertical: 40,
  },
  chartInfo: {
    flexDirection: 'row',
    gap: 16,
  },
  infoItem: {
    flex: 1,
    alignItems: 'center',
  },
  infoLabel: {
    fontSize: 11,
    color: '#999',
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  moistureDetailGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  moistureDetailItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
  },
  moistureDetailLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 6,
    fontWeight: '500',
  },
  moistureDetailValue: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  moistureDetailStatus: {
    fontSize: 11,
    color: '#999',
    fontWeight: '600',
  },
  thresholdNote: {
    fontSize: 11,
    color: '#999',
    fontStyle: 'italic',
    marginTop: 8,
  },
  summaryGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
  },
  summaryLabel: {
    fontSize: 11,
    color: '#999',
    marginBottom: 4,
  },
  summaryValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  footer: {
    height: 20,
  },
});

export default SensorsScreen;
