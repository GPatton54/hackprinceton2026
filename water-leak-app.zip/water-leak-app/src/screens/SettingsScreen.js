import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Switch,
  TextInput,
  TouchableOpacity,
  Alert as RNAlert,
  ActivityIndicator,
  SectionList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  subscribeToSettings,
  updateSettings,
} from '../services/firebaseService';

const SettingsScreen = () => {
  const [settings, setSettings] = useState(null);
  const [localSettings, setLocalSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [changed, setChanged] = useState(false);

  useEffect(() => {
    setLoading(true);

    // Subscribe to settings
    const unsubscribeSettings = subscribeToSettings((data) => {
      setSettings(data);
      setLocalSettings(data);
      setLoading(false);
    });

    return () => {
      unsubscribeSettings();
    };
  }, []);

  const handleThresholdChange = (key, value) => {
    const numValue = parseFloat(value);
    if (!isNaN(numValue)) {
      setLocalSettings((prev) => ({
        ...prev,
        [key]: numValue,
      }));
      setChanged(true);
    }
  };

  const handleSwitchChange = (key, value) => {
    setLocalSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
    setChanged(true);
  };

  const handleToggleNotification = (channel) => {
    const channels = localSettings.notification_channels || [];
    let newChannels;

    if (channels.includes(channel)) {
      newChannels = channels.filter((c) => c !== channel);
    } else {
      newChannels = [...channels, channel];
    }

    setLocalSettings((prev) => ({
      ...prev,
      notification_channels: newChannels,
    }));
    setChanged(true);
  };

  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      await updateSettings(localSettings);
      setSettings(localSettings);
      setChanged(false);
      RNAlert.alert('Success', 'Settings saved successfully');
    } catch (error) {
      RNAlert.alert('Error', 'Failed to save settings');
      setLocalSettings(settings); // Revert changes
    } finally {
      setSaving(false);
    }
  };

  const handleResetSettings = () => {
    RNAlert.alert(
      'Reset Settings',
      'Reset to default values?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: () => {
            const defaults = {
              flow_threshold_multiplier: 1.5,
              pressure_drop_threshold: 15,
              notification_channels: ['push'],
              electricity_rate: 0.004,
            };
            setLocalSettings(defaults);
            setChanged(true);
          },
        },
      ]
    );
  };

  if (loading || !localSettings) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Loading settings...</Text>
      </View>
    );
  }

  const sections = [
    {
      title: 'Detection Thresholds',
      data: [
        {
          id: 'flow_threshold',
          label: 'Flow Anomaly Multiplier',
          description:
            'Trigger alert when flow exceeds baseline by this multiplier (lower = more sensitive)',
          value: localSettings.flow_threshold_multiplier,
          min: 1.0,
          max: 3.0,
          step: 0.1,
          type: 'number',
        },
        {
          id: 'pressure_threshold',
          label: 'Pressure Drop Threshold',
          description: 'Trigger alert when pressure drops by this % (e.g., 15%)',
          value: localSettings.pressure_drop_threshold,
          min: 5,
          max: 50,
          step: 1,
          type: 'number',
        },
      ],
    },
    {
      title: 'Notifications',
      data: [
        {
          id: 'notifications',
          label: 'Notification Channels',
          type: 'multiselect',
          options: ['push', 'email', 'sms'],
          selected: localSettings.notification_channels || [],
        },
      ],
    },
    {
      title: 'Water Cost',
      data: [
        {
          id: 'electricity_rate',
          label: 'Water Rate ($ per gallon)',
          description: 'Used for cost estimation in statistics',
          value: localSettings.electricity_rate,
          min: 0.001,
          max: 0.1,
          step: 0.001,
          type: 'number',
        },
      ],
    },
  ];

  const renderThresholdItem = (item) => (
    <View key={item.id} style={styles.settingItem}>
      <View style={styles.settingHeader}>
        <Text style={styles.settingLabel}>{item.label}</Text>
        <View style={styles.settingInputContainer}>
          <TextInput
            style={styles.settingInput}
            value={item.value.toString()}
            onChangeText={(text) =>
              handleThresholdChange(
                item.id === 'flow_threshold'
                  ? 'flow_threshold_multiplier'
                  : item.id === 'pressure_threshold'
                  ? 'pressure_drop_threshold'
                  : 'electricity_rate',
                text
              )
            }
            keyboardType="decimal-pad"
            editable={!saving}
          />
          <Text style={styles.unitLabel}>
            {item.id === 'electricity_rate' ? '$/gal' : item.id === 'pressure_threshold' ? '%' : 'x'}
          </Text>
        </View>
      </View>
      <Text style={styles.settingDescription}>{item.description}</Text>
      <View style={styles.settingRange}>
        <Text style={styles.rangeLabel}>
          Min: {item.min} | Max: {item.max}
        </Text>
      </View>
    </View>
  );

  const renderNotificationItem = (item) => (
    <View key={item.id} style={styles.settingItem}>
      <Text style={styles.settingLabel}>{item.label}</Text>
      <View style={styles.notificationGrid}>
        {item.options.map((option) => (
          <TouchableOpacity
            key={option}
            style={[
              styles.notificationButton,
              item.selected.includes(option) &&
                styles.notificationButtonActive,
            ]}
            onPress={() => handleToggleNotification(option)}
            disabled={saving}
          >
            <Text
              style={[
                styles.notificationButtonText,
                item.selected.includes(option) &&
                  styles.notificationButtonTextActive,
              ]}
            >
              {option.charAt(0).toUpperCase() + option.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderSectionContent = (section) => {
    if (section.title === 'Notifications') {
      return section.data.map((item) => renderNotificationItem(item));
    } else {
      return section.data.map((item) => renderThresholdItem(item));
    }
  };

  return (
    <ScrollView style={styles.container}>
      {sections.map((section) => (
        <View key={section.title}>
          <Text style={styles.sectionTitle}>{section.title}</Text>
          <View style={styles.sectionContent}>
            {renderSectionContent(section)}
          </View>
        </View>
      ))}

      {/* Device Info */}
      <View>
        <Text style={styles.sectionTitle}>Device Information</Text>
        <View style={styles.sectionContent}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Firmware Version</Text>
            <Text style={styles.infoValue}>v1.0.0</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Last Connected</Text>
            <Text style={styles.infoValue}>Now</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Device ID</Text>
            <Text style={styles.infoValue}>ESP32_ALDS_001</Text>
          </View>
        </View>
      </View>

      {/* Action Buttons */}
      <View style={styles.actionButtons}>
        <TouchableOpacity
          style={[styles.button, styles.resetButton]}
          onPress={handleResetSettings}
          disabled={saving}
        >
          <Ionicons name="refresh" size={18} color="#FF9800" />
          <Text style={[styles.buttonText, { color: '#FF9800' }]}>
            Reset to Default
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.button,
            styles.saveButton,
            !changed && styles.saveButtonDisabled,
          ]}
          onPress={handleSaveSettings}
          disabled={!changed || saving}
        >
          {saving ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <>
              <Ionicons name="save" size={18} color="#fff" />
              <Text style={styles.buttonText}>
                {changed ? 'Save Changes' : 'No Changes'}
              </Text>
            </>
          )}
        </TouchableOpacity>
      </View>

      {/* Help Section */}
      <View>
        <Text style={styles.sectionTitle}>Help & Tips</Text>
        <View style={styles.helpCard}>
          <View style={styles.helpItem}>
            <Ionicons name="bulb" size={20} color="#FFC107" />
            <View style={styles.helpContent}>
              <Text style={styles.helpTitle}>Flow Multiplier</Text>
              <Text style={styles.helpText}>
                Lower values (1.0-1.5) are more sensitive; higher values
                (2.0-3.0) reduce false alerts. Start at 1.5.
              </Text>
            </View>
          </View>

          <View style={styles.helpItem}>
            <Ionicons name="bulb" size={20} color="#FFC107" />
            <View style={styles.helpContent}>
              <Text style={styles.helpTitle}>Moisture Sensors</Text>
              <Text style={styles.helpText}>
                Threshold is ~400 ADC units. If you get false positives, increase threshold in hardware.
              </Text>
            </View>
          </View>

          <View style={styles.helpItem}>
            <Ionicons name="bulb" size={20} color="#FFC107" />
            <View style={styles.helpContent}>
              <Text style={styles.helpTitle}>Push Notifications</Text>
              <Text style={styles.helpText}>
                Make sure app notifications are enabled in your phone's
                settings for instant alerts.
              </Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.footer} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    paddingHorizontal: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginTop: 20,
    marginBottom: 8,
  },
  sectionContent: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  settingItem: {
    marginBottom: 16,
  },
  settingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  settingLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
    flex: 1,
  },
  settingInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 6,
    paddingHorizontal: 8,
  },
  settingInput: {
    paddingVertical: 8,
    paddingHorizontal: 8,
    width: 60,
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
  },
  unitLabel: {
    fontSize: 12,
    color: '#999',
    marginLeft: 4,
  },
  settingDescription: {
    fontSize: 12,
    color: '#999',
    marginBottom: 6,
  },
  settingRange: {
    paddingVertical: 6,
    paddingHorizontal: 8,
    backgroundColor: '#f5f5f5',
    borderRadius: 6,
  },
  rangeLabel: {
    fontSize: 10,
    color: '#666',
    fontWeight: '500',
  },
  notificationGrid: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  notificationButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 8,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    alignItems: 'center',
  },
  notificationButtonActive: {
    backgroundColor: '#007AFF',
    borderColor: '#007AFF',
  },
  notificationButtonText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
  },
  notificationButtonTextActive: {
    color: '#fff',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  infoLabel: {
    fontSize: 13,
    color: '#666',
    fontWeight: '500',
  },
  infoValue: {
    fontSize: 13,
    color: '#333',
    fontWeight: '600',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 20,
    marginBottom: 20,
  },
  button: {
    flex: 1,
    flexDirection: 'row',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  resetButton: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#FF9800',
  },
  saveButton: {
    backgroundColor: '#007AFF',
  },
  saveButtonDisabled: {
    backgroundColor: '#ccc',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  helpCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  helpItem: {
    flexDirection: 'row',
    marginBottom: 16,
    gap: 12,
  },
  helpContent: {
    flex: 1,
  },
  helpTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  helpText: {
    fontSize: 12,
    color: '#666',
    lineHeight: 18,
  },
  footer: {
    height: 20,
  },
});

export default SettingsScreen;
