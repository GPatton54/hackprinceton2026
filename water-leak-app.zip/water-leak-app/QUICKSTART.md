# Quick Start Guide (5 Minutes)

## For Hackathon Teams - Get This Running NOW

### Step 1: Install Dependencies (2 min)
```bash
cd water-leak-app
npm install
```

### Step 2: Create Firebase Project (1 min)
1. Go to https://console.firebase.google.com
2. Click "Create Project" → name it `water-leak-app`
3. Wait for creation

### Step 3: Set Up Firebase Realtime Database (1 min)
1. In Firebase Console, click "Realtime Database"
2. Click "Create Database" → choose location → "Start in test mode"
3. Click "Enable"

### Step 4: Get Firebase Config (30 sec)
1. Click gear icon → "Project Settings"
2. Scroll down to "Your apps" → click "Web"
3. Copy the config object (looks like):
```javascript
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "...",
  projectId: "...",
  storageBucket: "...",
  messagingSenderId: "...",
  appId: "...",
  databaseURL: "https://YOUR-PROJECT.firebaseio.com"
};
```

### Step 5: Update App Config (30 sec)
1. Open `src/services/firebaseConfig.js`
2. Replace `firebaseConfig` with your config from Step 4
3. Save file

### Step 6: Start App (30 sec)
```bash
npm start
```

Then:
- **iOS:** Press `i` or scan QR code with Expo Go
- **Android:** Press `a` or scan QR code with Expo Go

### Step 7: Test Firebase (1 min)
1. App should show "Loading sensor data..."
2. Go to Firebase Console → "Realtime Database"
3. Manually add this test data:
```json
{
  "currentReading": {
    "flow_gpm": 0.35,
    "pressure_psi": 50.2,
    "temp_c": 18.5,
    "moisture_kitchen": 150,
    "moisture_basement": 80,
    "moisture_bathroom": 75,
    "valve_state": "OPEN",
    "baseline_anomaly_percent": 25,
    "timestamp": 1234567890
  }
}
```

4. App should update within 5 seconds!

## Next Steps

- [ ] Home screen shows live data
- [ ] Try clicking OPEN/CLOSE buttons
- [ ] View Sensors tab for charts
- [ ] View History tab for alerts
- [ ] Go to Settings to configure

## Connecting to Hardware

Once app is running, connect your ESP32:

1. **ESP32 Firmware:** Write sensor data to Firebase `/currentReading`
2. **Real Alerts:** Create alerts in Firebase `/alerts` (see FIREBASE_SETUP.md)
3. **Push Notifications:** iOS/Android will auto-notify on new alerts

## Troubleshooting

| Problem | Solution |
|---------|----------|
| App won't start | Run `npm install` again |
| "Loading..." forever | Check Firebase config in firebaseConfig.js |
| No data showing | Manually add test data to Firebase (Step 7) |
| Charts empty | Refresh app or wait 10 sec for data |

## Common Commands

```bash
npm start          # Start development server
npm run web        # Run on web browser
npm run android    # Run on Android device
npm run ios        # Run on iOS device
npm test           # Run tests
```

---

**Total Time:** ~5 minutes to running app

For detailed setup, see `README.md` and `FIREBASE_SETUP.md`.
