# Firebase Configuration & Setup Guide

This guide will help you set up Firebase for the Water Leak Detection app.

## Step 1: Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Click "Create a project"
3. Enter project name: `water-leak-app`
4. Accept the terms and click "Create project"
5. Wait for project to be created (~1 minute)

## Step 2: Set Up Realtime Database

1. In Firebase Console, click on "Realtime Database" (left sidebar)
2. Click "Create Database"
3. Choose location closest to you (e.g., `us-east1`)
4. Choose "Start in test mode" (for MVP/hackathon)
5. Click "Enable"

**Important for production:** Update security rules to restrict public access:
```json
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
```

For hackathon MVP, test mode is fine but remember to add authentication before deploying.

## Step 3: Initialize Authentication (Optional for MVP)

1. Go to "Authentication" in Firebase Console
2. Click "Get Started"
3. Enable "Anonymous" authentication (easy for MVP testing)
4. Click "Enable" and "Save"

## Step 4: Get Firebase Config

1. Go to Project Settings (click gear icon in top-left)
2. Click "Your apps" section
3. Click "Web" (or create a new web app if needed)
4. Copy the config object that looks like:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyD...",
  authDomain: "water-leak-app-xxxxx.firebaseapp.com",
  projectId: "water-leak-app-xxxxx",
  storageBucket: "water-leak-app-xxxxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456",
  databaseURL: "https://water-leak-app-xxxxx.firebaseio.com"
};
```

## Step 5: Update App Configuration

1. Open `src/services/firebaseConfig.js`
2. Replace the `firebaseConfig` object with your config from Step 4
3. Save the file

## Step 6: Create Firebase Database Structure

1. In Firebase Console, go to Realtime Database
2. Click the "Data" tab
3. Manually create the following structure by clicking the "+" button:

### Create `/currentReading` node:
```json
{
  "currentReading": {
    "flow_gpm": 0.35,
    "pressure_psi": 50.2,
    "temp_c": 18.5,
    "moisture_kitchen": 150,
    "moisture_basement": 80,
    "moisture_bathroom": 75,
    "valve_state": "OPEN",
    "baseline_anomaly_percent": 25,
    "timestamp": 1234567890
  }
}
```

### Create `/baseline` node (sample):
```json
{
  "baseline": {
    "0": 0.0,
    "1": 0.0,
    "2": 0.05,
    "3": 0.1,
    "4": 0.2,
    "5": 0.5,
    "6": 1.5,
    "7": 1.8,
    "8": 1.2,
    "9": 0.8,
    "10": 0.6,
    "11": 0.7,
    "12": 0.9,
    "13": 1.1,
    "14": 0.8,
    "15": 1.2,
    "16": 1.5,
    "17": 2.0,
    "18": 1.8,
    "19": 1.5,
    "20": 1.2,
    "21": 0.9,
    "22": 0.5,
    "23": 0.1
  }
}
```

### Create `/alerts` node:
```json
{
  "alerts": {
    "alert_001": {
      "timestamp": 1234567890,
      "type": "FLOW_SPIKE",
      "severity": "HIGH",
      "flow_gpm": 0.8,
      "baseline_gpm": 0.1,
      "duration_sec": 30
    }
  }
}
```

### Create `/settings` node:
```json
{
  "settings": {
    "flow_threshold_multiplier": 1.5,
    "pressure_drop_threshold": 15,
    "notification_channels": ["push"],
    "electricity_rate": 0.004
  }
}
```

### Create `/commands` node:
```json
{
  "commands": {
    "shutoff": {
      "command": "OPEN",
      "timestamp": 1234567890,
      "requested_by": "app"
    }
  }
}
```

## Step 7: Test Firebase Connection

1. In your app, navigate to any screen
2. Open DevTools/Console (if available)
3. You should see Firebase initialization messages
4. If data doesn't appear in 5 seconds, check:
   - Firebase config is correct in `firebaseConfig.js`
   - Database rules allow read access (should be in test mode)
   - Network connectivity (check phone is connected to WiFi)

## Firebase Database Structure Reference

```
root/
├── currentReading/          # Latest sensor values (live updates)
│   ├── flow_gpm
│   ├── pressure_psi
│   ├── temp_c
│   ├── moisture_kitchen
│   ├── moisture_basement
│   ├── moisture_bathroom
│   ├── valve_state
│   ├── baseline_anomaly_percent
│   └── timestamp
├── baseline/                # Hour-by-hour baseline (0-23)
│   ├── 0: (2am average flow)
│   ├── 1: (3am average flow)
│   └── ... (one entry per hour)
├── alerts/                  # Historical alert log
│   ├── alert_001
│   ├── alert_002
│   └── ...
├── settings/                # User-configurable settings
│   ├── flow_threshold_multiplier
│   ├── pressure_drop_threshold
│   ├── notification_channels
│   └── electricity_rate
└── commands/                # Commands from app to device
    └── shutoff
        ├── command ("OPEN" or "CLOSE")
        ├── timestamp
        └── requested_by
```

## Connecting ESP32 to Firebase

When setting up your firmware on the ESP32, you'll also need to configure it to write to Firebase.

**Key settings for ESP32:**
- `databaseURL`: `https://YOUR_PROJECT_ID.firebaseio.com`
- WiFi SSID/Password (hardcoded for MVP)
- Update `/currentReading` every 5 seconds
- Append alerts to `/alerts` node
- Read `/settings` and `/commands` periodically

See `FIRMWARE_SETUP.md` for ESP32 code examples.

## Troubleshooting

### Issue: App shows "Loading..." forever
**Solution:**
- Check Firebase config in `firebaseConfig.js`
- Verify WiFi is connected
- Check Firebase Realtime Database is created
- Go to Firebase Console > Database > Rules and verify test mode is enabled

### Issue: Data not updating
**Solution:**
- Check that `/currentReading` node exists in Firebase
- Verify ESP32 is writing to Firebase (check Firebase Console > Data)
- Check network connectivity

### Issue: Alerts not appearing
**Solution:**
- Verify `/alerts` node exists
- Check that ESP32 firmware is appending alerts correctly
- Look at Firebase Console > Database to see if alerts are being written

### Issue: Shutoff button not working
**Solution:**
- Verify `/commands/shutoff` node exists in Firebase
- Check that ESP32 is reading from `/commands` node
- Verify solenoid valve relay is wired correctly

## Next Steps

1. **Set up Firebase** using this guide
2. **Update `src/services/firebaseConfig.js`** with your Firebase credentials
3. **Test app connection** by running the app and checking for data
4. **Prepare ESP32 firmware** to write test data to Firebase
5. **Run full end-to-end test** with hardware + app

## Additional Resources

- [Firebase Realtime Database Docs](https://firebase.google.com/docs/database)
- [Firebase Console](https://console.firebase.google.com)
- [Firebase Security Rules](https://firebase.google.com/docs/database/security)

---

**Tip:** For the hackathon MVP, having test mode enabled is fine. Just remember to tighten security rules before any production deployment.
